import type { ReactNode } from "react";
import type { DataRelayIconName } from "@datarelay-labs/icons";
import type { ProductCapabilityMap, ProductIdentity, ProductNavigationItem } from "@datarelay-labs/product-shell";
export type ProductAdapterRegistry = Readonly<Record<string, unknown>>;
export type ProductExtensionNavigation = {
    label: string;
    icon?: DataRelayIconName;
    group?: string;
    requiredCapability?: string;
};
export type ProductExtension = {
    id: string;
    route: {
        path: string;
        component: ReactNode;
    };
    navigation?: ProductExtensionNavigation;
};
export type FoundationProductIdentity = ProductIdentity & {
    id: string;
};
export type ProductIntegration<Adapters extends ProductAdapterRegistry = ProductAdapterRegistry> = {
    product: FoundationProductIdentity;
    navigation: readonly ProductNavigationItem[];
    capabilities?: ProductCapabilityMap;
    adapters?: Adapters;
    extensions?: readonly ProductExtension[];
};
export declare function validateProductIntegration(integration: ProductIntegration): void;
export declare function defineExtension<const Extension extends ProductExtension>(extension: Extension): Extension;
export declare function defineProduct<const Adapters extends ProductAdapterRegistry, const Integration extends ProductIntegration<Adapters>>(integration: Integration): Integration;
