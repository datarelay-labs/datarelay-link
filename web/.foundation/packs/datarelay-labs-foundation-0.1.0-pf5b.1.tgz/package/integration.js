const PRODUCT_ID = /^[a-z][a-z0-9-]{1,63}$/;
const EXTENSION_ID = /^[a-z][a-z0-9._-]{1,119}$/;
function invariant(condition, reason) {
    if (!condition)
        throw new Error(`FOUNDATION_INTEGRATION_INVALID=${reason}`);
}
function validatePath(value, label) {
    invariant(value.startsWith("/"), `${label}:path-must-start-with-slash`);
}
export function validateProductIntegration(integration) {
    invariant(PRODUCT_ID.test(integration.product.id), "product-id");
    invariant(integration.product.name.trim().length > 0, "product-name");
    validatePath(integration.product.homePath, "product-home");
    const navigationIds = new Set();
    const navigationPaths = new Set();
    for (const item of integration.navigation) {
        invariant(item.id.trim().length > 0, "navigation-id");
        invariant(!navigationIds.has(item.id), `duplicate-navigation-id:${item.id}`);
        navigationIds.add(item.id);
        validatePath(item.path, `navigation:${item.id}`);
        invariant(!navigationPaths.has(item.path), `duplicate-navigation-path:${item.path}`);
        navigationPaths.add(item.path);
    }
    const extensionIds = new Set();
    const extensionPaths = new Set();
    for (const extension of integration.extensions ?? []) {
        invariant(EXTENSION_ID.test(extension.id), `extension-id:${extension.id}`);
        invariant(!extensionIds.has(extension.id), `duplicate-extension-id:${extension.id}`);
        extensionIds.add(extension.id);
        validatePath(extension.route.path, `extension:${extension.id}`);
        invariant(!extensionPaths.has(extension.route.path), `duplicate-extension-path:${extension.route.path}`);
        invariant(!navigationPaths.has(extension.route.path), `route-owned-by-navigation:${extension.route.path}`);
        extensionPaths.add(extension.route.path);
    }
}
export function defineExtension(extension) {
    validateProductIntegration({
        product: { id: "extension-check", name: "Extension", homePath: "/" },
        navigation: [],
        extensions: [extension]
    });
    return extension;
}
export function defineProduct(integration) {
    validateProductIntegration(integration);
    return integration;
}
