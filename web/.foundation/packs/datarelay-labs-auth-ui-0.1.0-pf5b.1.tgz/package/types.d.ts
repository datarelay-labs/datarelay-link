import type { ReactNode } from "react";
export declare const AUTH_CAPABILITIES: {
    readonly passwordChange: "identity.password.change";
    readonly mfaTotp: "identity.mfa.totp";
    readonly mfaRecovery: "identity.mfa.recovery";
    readonly sessionList: "session.list";
    readonly sessionRevoke: "session.revoke";
};
export type AuthCapability = (typeof AUTH_CAPABILITIES)[keyof typeof AUTH_CAPABILITIES];
export type AuthErrorCategory = "validation" | "unauthenticated" | "forbidden" | "conflict" | "stale_state" | "unavailable" | "interrupted" | "failed";
export type AuthResourceLink = {
    title: string;
    href: string;
    description?: string;
    external?: boolean;
};
export type AuthProductIdentity = {
    productName: string;
    productSubtitle?: string;
    description?: string;
    brandMark?: ReactNode;
    resources?: readonly AuthResourceLink[];
};
export type LoginSubmission = {
    username: string;
    password: string;
};
export type PasswordChangeSubmission = {
    currentPassword?: string;
    newPassword: string;
    confirmPassword: string;
};
export type AuthSecondFactorMethod = "totp" | "recovery_code";
export type MfaChallengeSubmission = {
    method: AuthSecondFactorMethod;
    value: string;
    challengeRef?: string;
};
export type MfaEnrollmentMaterial = {
    accountLabel: string;
    issuer?: string;
    secret?: string;
    otpauthUri?: string;
    qrCode?: ReactNode;
};
export type AuthSessionSummary = {
    id: string;
    deviceLabel?: string;
    createdAt: string;
    lastSeenAt?: string;
    expiresAt?: string;
    source?: string;
    current?: boolean;
    revoked?: boolean;
    revocable?: boolean;
};
export type AuthFlowResult<Principal = unknown> = {
    state: "authenticated";
    principal: Principal;
} | {
    state: "password_change_required";
    principal?: Principal;
} | {
    state: "mfa_required";
    methods: readonly AuthSecondFactorMethod[];
    challengeRef?: string;
};
export type AuthAdapter<Principal = unknown> = {
    getPrincipal?: () => Promise<Principal | null>;
    getCapabilities?: () => Promise<readonly AuthCapability[]>;
    signIn: (credentials: LoginSubmission) => Promise<AuthFlowResult<Principal>>;
    signOut: () => Promise<void>;
    changePassword?: (request: PasswordChangeSubmission) => Promise<AuthFlowResult<Principal> | void>;
    verifyMfa?: (request: MfaChallengeSubmission) => Promise<AuthFlowResult<Principal>>;
    listSessions?: () => Promise<readonly AuthSessionSummary[]>;
    revokeSession?: (sessionId: string) => Promise<void>;
};
