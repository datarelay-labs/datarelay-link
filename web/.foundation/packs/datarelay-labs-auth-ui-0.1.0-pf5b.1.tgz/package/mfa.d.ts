import type { AuthErrorCategory, AuthSecondFactorMethod, MfaChallengeSubmission, MfaEnrollmentMaterial } from "./types";
export type MfaChallengeFormProps = {
    onSubmit: (submission: MfaChallengeSubmission) => void | Promise<void>;
    methods?: readonly AuthSecondFactorMethod[];
    challengeRef?: string;
    busy?: boolean;
    errorCategory?: AuthErrorCategory;
    errorMessage?: string;
};
export declare function MfaChallengeForm({ onSubmit, methods, challengeRef, busy, errorCategory, errorMessage }: MfaChallengeFormProps): import("react").JSX.Element;
export type MfaEnrollmentPanelProps = {
    material: MfaEnrollmentMaterial;
    onConfirm: (code: string) => void | Promise<void>;
    busy?: boolean;
    errorCategory?: AuthErrorCategory;
    errorMessage?: string;
};
export declare function MfaEnrollmentPanel({ material, onConfirm, busy, errorCategory, errorMessage }: MfaEnrollmentPanelProps): import("react").JSX.Element;
export type RecoveryCodesPanelProps = {
    codes: readonly string[];
    onContinue?: () => void;
    onCopyRequested?: () => void;
};
export declare function RecoveryCodesPanel({ codes, onContinue, onCopyRequested }: RecoveryCodesPanelProps): import("react").JSX.Element;
