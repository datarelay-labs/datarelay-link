import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import { Alert, Button, TextField } from "@datarelay-labs/ui";
import { AuthErrorNotice } from "./auth-error-notice.js";
export function LoginForm({ onSubmit, busy = false, errorCategory, errorMessage, infoMessage, initialUsername = "", submitLabel = "Sign in" }) {
    const [username, setUsername] = useState(initialUsername);
    const [password, setPassword] = useState("");
    const [localError, setLocalError] = useState("");
    function submit(event) {
        event.preventDefault();
        const normalized = username.trim();
        if (!normalized || !password) {
            setLocalError("Enter your username and password.");
            return;
        }
        setLocalError("");
        void onSubmit({ username: normalized, password });
    }
    return (_jsxs("form", { className: "dr-auth-form", onSubmit: submit, children: [_jsx(TextField, { label: "Username", autoComplete: "username", value: username, onChange: (event) => setUsername(event.target.value), disabled: busy }), _jsx(TextField, { label: "Password", type: "password", autoComplete: "current-password", value: password, onChange: (event) => setPassword(event.target.value), disabled: busy }), infoMessage ? _jsx(Alert, { tone: "info", title: "Information", children: infoMessage }) : null, localError ? _jsx(AuthErrorNotice, { category: "validation", message: localError }) : null, errorCategory ? _jsx(AuthErrorNotice, { category: errorCategory, ...(errorMessage ? { message: errorMessage } : {}) }) : null, _jsx(Button, { type: "submit", disabled: busy, children: busy ? "Signing in…" : submitLabel })] }));
}
