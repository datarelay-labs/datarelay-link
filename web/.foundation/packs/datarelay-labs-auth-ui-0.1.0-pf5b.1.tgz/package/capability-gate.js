import { Fragment as _Fragment, jsx as _jsx } from "react/jsx-runtime";
export function AuthCapabilityGate({ available, children, fallback = null }) {
    return _jsx(_Fragment, { children: available ? children : fallback });
}
