import type { AuthErrorCategory, LoginSubmission } from "./types";
export type LoginFormProps = {
    onSubmit: (submission: LoginSubmission) => void | Promise<void>;
    busy?: boolean;
    errorCategory?: AuthErrorCategory;
    errorMessage?: string;
    infoMessage?: string;
    initialUsername?: string;
    submitLabel?: string;
};
export declare function LoginForm({ onSubmit, busy, errorCategory, errorMessage, infoMessage, initialUsername, submitLabel }: LoginFormProps): import("react").JSX.Element;
