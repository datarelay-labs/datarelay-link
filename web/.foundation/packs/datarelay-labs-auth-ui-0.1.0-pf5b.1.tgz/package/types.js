export const AUTH_CAPABILITIES = {
    passwordChange: "identity.password.change",
    mfaTotp: "identity.mfa.totp",
    mfaRecovery: "identity.mfa.recovery",
    sessionList: "session.list",
    sessionRevoke: "session.revoke"
};
