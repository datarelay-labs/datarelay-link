import type { ReactNode } from "react";
import type { AuthResourceLink } from "./types";
export type AuthLayoutProps = {
    productName: string;
    productSubtitle?: string;
    description?: string;
    title: string;
    subtitle?: string;
    resources?: readonly AuthResourceLink[];
    brandMark?: ReactNode;
    children: ReactNode;
};
export declare function AuthLayout({ productName, productSubtitle, description, title, subtitle, resources, brandMark, children }: AuthLayoutProps): import("react").JSX.Element;
