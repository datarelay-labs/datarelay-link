import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Card, StatusBadge } from "@datarelay-labs/ui";
export function SystemStatus({ health, info }) {
    const healthTone = health?.status === "healthy"
        ? "success"
        : health?.status === "unhealthy"
            ? "critical"
            : health?.status === "degraded"
                ? "warning"
                : "neutral";
    return (_jsxs("div", { className: "dr-admin__status-grid", children: [health ? (_jsx(Card, { title: "Health", actions: _jsx(StatusBadge, { tone: healthTone, children: health.status }), children: health.checks?.length ? (_jsx("ul", { className: "dr-admin__check-list", children: health.checks.map((check) => (_jsxs("li", { children: [_jsx("span", { children: check.label }), _jsx("span", { children: check.status }), check.detail ? _jsx("small", { children: check.detail }) : null] }, check.id))) })) : _jsx("p", { className: "dr-admin__muted", children: "No component checks were supplied." }) })) : null, info ? (_jsx(Card, { title: "System information", children: _jsx("dl", { className: "dr-admin__facts", children: info.facts.map((fact) => (_jsxs("div", { children: [_jsx("dt", { children: fact.label }), _jsx("dd", { children: fact.value })] }, fact.id))) }) })) : null] }));
}
