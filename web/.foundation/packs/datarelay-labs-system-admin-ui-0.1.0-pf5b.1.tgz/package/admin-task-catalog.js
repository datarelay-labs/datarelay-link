import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, Card, StatusBadge } from "@datarelay-labs/ui";
import { capabilityInteractive, capabilityVisible } from "@datarelay-labs/system-contracts";
function effectLabel(effect) {
    return effect.replaceAll("_", " ");
}
export function AdminTaskCatalog({ tasks, onOpen, showUnavailable = false, taskSpecificActionNames = false }) {
    const visible = tasks.filter((task) => showUnavailable || capabilityVisible(task.availability));
    if (visible.length === 0) {
        return _jsx("p", { className: "dr-admin__muted", children: "No administration tasks are available." });
    }
    return (_jsx("div", { className: "dr-admin__task-grid", children: visible.map((task) => {
            const interactive = capabilityInteractive(task.availability);
            return (_jsxs(Card, { title: task.label, description: task.description, actions: _jsx(StatusBadge, { tone: task.availability === "supported"
                        ? "success"
                        : task.availability === "read_only"
                            ? "info"
                            : "neutral", children: task.availability.replace("_", " ") }), children: [task.effects?.length ? (_jsx("ul", { className: "dr-admin__effects", "aria-label": task.label + " effects", children: task.effects.map((effect) => _jsx("li", { children: effectLabel(effect) }, effect)) })) : null, task.notes ? _jsx("p", { className: "dr-admin__muted", children: task.notes }) : null, onOpen && task.availability !== "unavailable" ? (_jsx(Button, { variant: interactive ? "primary" : "secondary", ...(taskSpecificActionNames ? { "aria-label": `${interactive ? "Manage" : "View"} ${task.label}` } : {}), onClick: () => onOpen(task), children: interactive ? "Manage" : "View" })) : null] }, task.id));
        }) }));
}
