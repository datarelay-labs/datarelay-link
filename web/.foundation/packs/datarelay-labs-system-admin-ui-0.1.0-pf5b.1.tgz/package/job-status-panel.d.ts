import type { ReactNode } from "react";
import type { JobProjection } from "@datarelay-labs/system-contracts";
export type JobStatusPanelProps<Result = unknown> = {
    job: JobProjection<Result>;
    onCancel?: (jobId: string) => void | Promise<void>;
    renderResult?: (result: Result) => ReactNode;
};
export declare function JobStatusPanel<Result = unknown>({ job, onCancel, renderResult }: JobStatusPanelProps<Result>): import("react").JSX.Element;
