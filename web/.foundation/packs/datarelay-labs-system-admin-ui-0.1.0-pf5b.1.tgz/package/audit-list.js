import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { EmptyState } from "@datarelay-labs/ui";
export function AuditList({ events }) {
    if (events.length === 0) {
        return _jsx(EmptyState, { title: "No audit events", description: "No events match the current product query." });
    }
    return (_jsx("div", { className: "dr-admin__audit-table-wrap", role: "region", "aria-label": "Audit history", tabIndex: 0, children: _jsxs("table", { className: "dr-admin__audit-table", children: [_jsx("thead", { children: _jsxs("tr", { children: [_jsx("th", { children: "Time" }), _jsx("th", { children: "Action" }), _jsx("th", { children: "Actor" }), _jsx("th", { children: "Outcome" }), _jsx("th", { children: "Reference" })] }) }), _jsx("tbody", { children: events.map((event) => (_jsxs("tr", { children: [_jsx("td", { children: event.timestamp }), _jsxs("td", { children: [_jsx("strong", { children: event.action }), event.summary ? _jsx("small", { children: event.summary }) : null] }), _jsx("td", { children: event.actor ?? "—" }), _jsx("td", { children: event.outcome ?? "—" }), _jsx("td", { children: event.reference ?? event.id })] }, event.id))) })] }) }));
}
