import type { ReactNode } from "react";
import type { AccountProjection } from "@datarelay-labs/system-contracts";
export type AccountListProps<RoleValue = string> = {
    accounts: readonly AccountProjection<RoleValue>[];
    actions?: (account: AccountProjection<RoleValue>) => ReactNode;
};
export declare function AccountList<RoleValue = string>({ accounts, actions }: AccountListProps<RoleValue>): import("react").JSX.Element;
