const PRODUCT_ID = /^[a-z][a-z0-9-]{1,63}$/;
const EXTENSION_ID = /^[a-z][a-z0-9._-]{1,119}$/;
function invariant(condition, reason) {
    if (!condition)
        throw new Error(`FOUNDATION_INTEGRATION_INVALID=${reason}`);
}
function validatePath(value, label) {
    invariant(value.startsWith("/"), `${label}:path-must-start-with-slash`);
}
export function validateProductIntegration(integration) {
    invariant(PRODUCT_ID.test(integration.product.id), "product-id");
    invariant(integration.product.name.trim().length > 0, "product-name");
    validatePath(integration.product.homePath, "product-home");
    const navigationIds = new Set();
    const navigationPaths = new Set();
    const sections = new Map();
    function registerId(id) {
        invariant(id.trim().length > 0, "navigation-id");
        invariant(!navigationIds.has(id), "duplicate-navigation-id:" + id);
        navigationIds.add(id);
    }
    function registerPath(id, path) {
        validatePath(path, "navigation:" + id);
        invariant(!navigationPaths.has(path), "duplicate-navigation-path:" + path);
        navigationPaths.add(path);
    }
    for (const item of integration.navigation) {
        registerId(item.id);
        if ("children" in item) {
            invariant(!("path" in item) || item.path === undefined, "navigation-parent-cannot-route:" + item.id);
            invariant(item.children.length > 0, "empty-navigation-parent:" + item.id);
            for (const child of item.children) {
                registerId(child.id);
                registerPath(child.id, child.path);
            }
        }
        else {
            registerPath(item.id, item.path);
            if (item.section) {
                const section = item.section;
                invariant(section.id.trim().length > 0, "navigation-section-id");
                const fingerprint = JSON.stringify([
                    section.label, section.icon ?? null,
                    section.defaultExpanded ?? false, section.requiredCapability ?? null
                ]);
                const previous = sections.get(section.id);
                if (previous !== undefined) {
                    invariant(previous === fingerprint, "navigation-section-metadata-conflict:" + section.id);
                }
                else {
                    registerId(section.id);
                    sections.set(section.id, fingerprint);
                }
            }
        }
    }
    const extensionIds = new Set();
    const extensionPaths = new Set();
    for (const extension of integration.extensions ?? []) {
        invariant(EXTENSION_ID.test(extension.id), `extension-id:${extension.id}`);
        invariant(!extensionIds.has(extension.id), `duplicate-extension-id:${extension.id}`);
        extensionIds.add(extension.id);
        validatePath(extension.route.path, `extension:${extension.id}`);
        invariant(!extensionPaths.has(extension.route.path), `duplicate-extension-path:${extension.route.path}`);
        invariant(!navigationPaths.has(extension.route.path), `route-owned-by-navigation:${extension.route.path}`);
        extensionPaths.add(extension.route.path);
    }
}
export function defineExtension(extension) {
    validateProductIntegration({
        product: { id: "extension-check", name: "Extension", homePath: "/" },
        navigation: [],
        extensions: [extension]
    });
    return extension;
}
export function defineProduct(integration) {
    validateProductIntegration(integration);
    return integration;
}
