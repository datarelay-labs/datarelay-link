import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import {
  FOUNDATION_PACKAGE_FAMILY,
  doctorProject
} from "./doctor.mjs";

const FOUNDATION_PACKAGE_SET = new Set(FOUNDATION_PACKAGE_FAMILY);
const DEPENDENCY_SECTIONS = [
  "dependencies",
  "devDependencies",
  "optionalDependencies",
  "peerDependencies"
];
const EXACT_SEMVER =
  /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+([0-9A-Za-z.-]+))?$/;

function fail(reason) {
  throw new Error(`FOUNDATION_UPGRADE_INVALID=${reason}`);
}

function readFileState(file) {
  if (!fs.existsSync(file)) return { exists: false, bytes: null };
  const stat = fs.lstatSync(file);
  if (stat.isSymbolicLink() || !stat.isFile()) {
    fail(`not-regular-file:${file}`);
  }
  return { exists: true, bytes: fs.readFileSync(file) };
}

function restoreFileState(file, state) {
  if (!state.exists) {
    fs.rmSync(file, { force: true });
    return;
  }
  atomicWrite(file, state.bytes);
}

function atomicWrite(file, bytes) {
  const dir = path.dirname(file);
  const temp = path.join(
    dir,
    `.${path.basename(file)}.foundation-${process.pid}-${crypto.randomBytes(6).toString("hex")}`
  );
  fs.writeFileSync(temp, bytes);
  fs.renameSync(temp, file);
}

function jsonIndent(text) {
  const match = text.match(/\n([ \t]+)"/);
  return match?.[1] ?? "  ";
}

function writeJsonLike(file, originalText, value) {
  const indent = jsonIndent(originalText);
  const text = JSON.stringify(value, null, indent) + "\n";
  atomicWrite(file, Buffer.from(text, "utf8"));
}

function parseVersion(value, label = "version") {
  if (typeof value !== "string") fail(`${label}-not-string`);
  const match = value.match(EXACT_SEMVER);
  if (!match) fail(`${label}-not-exact-semver:${value}`);
  return {
    raw: value,
    major: Number(match[1]),
    minor: Number(match[2]),
    patch: Number(match[3]),
    prerelease: match[4] ?? null
  };
}

function compareIdentifiers(left, right) {
  const leftNumeric = /^\d+$/.test(left);
  const rightNumeric = /^\d+$/.test(right);
  if (leftNumeric && rightNumeric) return Number(left) - Number(right);
  if (leftNumeric) return -1;
  if (rightNumeric) return 1;
  return left < right ? -1 : left > right ? 1 : 0;
}

function compareVersions(leftValue, rightValue) {
  const left = typeof leftValue === "string" ? parseVersion(leftValue) : leftValue;
  const right =
    typeof rightValue === "string" ? parseVersion(rightValue) : rightValue;
  for (const key of ["major", "minor", "patch"]) {
    if (left[key] !== right[key]) return left[key] < right[key] ? -1 : 1;
  }
  if (left.prerelease === right.prerelease) return 0;
  if (left.prerelease === null) return 1;
  if (right.prerelease === null) return -1;
  const leftParts = left.prerelease.split(".");
  const rightParts = right.prerelease.split(".");
  const count = Math.max(leftParts.length, rightParts.length);
  for (let index = 0; index < count; index += 1) {
    if (leftParts[index] === undefined) return -1;
    if (rightParts[index] === undefined) return 1;
    const compared = compareIdentifiers(leftParts[index], rightParts[index]);
    if (compared !== 0) return compared < 0 ? -1 : 1;
  }
  return 0;
}

function classifyTransition(current, target) {
  const compared = compareVersions(current, target);
  if (compared === 0) return current.raw === target.raw ? "noop" : "metadata";
  if (compared > 0) return "downgrade";
  if (current.major !== target.major) return "major";
  if (current.minor !== target.minor) return "minor";
  return "patch";
}

function readJson(file, label) {
  let text;
  try {
    const stat = fs.lstatSync(file);
    if (stat.isSymbolicLink() || !stat.isFile()) fail(`${label}-unsafe:${file}`);
    text = fs.readFileSync(file, "utf8");
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("FOUNDATION_UPGRADE_INVALID=")) {
      throw error;
    }
    fail(`${label}-missing:${file}`);
  }
  try {
    return { text, value: JSON.parse(text) };
  } catch {
    fail(`${label}-json:${file}`);
  }
}

function validateMigrationBoundary(file, current, target) {
  if (!file) fail("major-migration-metadata-required");
  const { value } = readJson(path.resolve(file), "migration");
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    fail("migration-object");
  }
  if (value.schema_version !== 1) fail("migration-schema-version");
  if (
    value.from_major !== current.major ||
    value.to_major !== target.major ||
    value.target_version !== target.raw
  ) {
    fail("migration-boundary-mismatch");
  }
  const allowed = new Set([
    "schema_version",
    "migration_id",
    "from_major",
    "to_major",
    "target_version",
    "codemod_required",
    "notes"
  ]);
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) fail(`migration-unknown-field:${key}`);
  }
  if (
    typeof value.migration_id !== "string" ||
    !/^[a-z0-9][a-z0-9._-]*$/.test(value.migration_id) ||
    value.migration_id.length > 120
  ) {
    fail("migration-id");
  }
  if (
    !Number.isInteger(value.from_major) ||
    value.from_major < 0 ||
    !Number.isInteger(value.to_major) ||
    value.to_major < 0
  ) {
    fail("migration-major");
  }
  if (
    value.notes !== undefined &&
    (typeof value.notes !== "string" || value.notes.length > 1000)
  ) {
    fail("migration-notes");
  }
  if (value.codemod_required === true) {
    fail("codemod-required-not-supported");
  }
  if (value.codemod_required !== false) {
    fail("migration-codemod-declaration");
  }
  return {
    migrationId: value.migration_id,
    codemodRequired: false
  };
}

function foundationDependencies(packageManifest) {
  const found = [];
  for (const section of DEPENDENCY_SECTIONS) {
    const values = packageManifest[section];
    if (!values || typeof values !== "object" || Array.isArray(values)) continue;
    for (const [name, spec] of Object.entries(values)) {
      if (!FOUNDATION_PACKAGE_SET.has(name)) continue;
      found.push({ section, name, spec });
    }
  }
  return found.sort((a, b) =>
    a.section === b.section
      ? a.name.localeCompare(b.name)
      : a.section.localeCompare(b.section)
  );
}

export function planUpgrade({
  root = process.cwd(),
  targetVersion,
  allowMajor = false,
  allowDowngrade = false,
  migrationPath
}) {
  const resolvedRoot = path.resolve(root);
  const packageFile = path.join(resolvedRoot, "package.json");
  const { value: packageManifest } = readJson(packageFile, "package");
  const currentInspection = doctorProject({ root: resolvedRoot });
  const current = parseVersion(currentInspection.foundationVersion, "current-version");
  const target = parseVersion(targetVersion, "target-version");
  const transition = classifyTransition(current, target);

  if (transition === "downgrade" && !allowDowngrade) {
    fail("downgrade-requires-allow-downgrade");
  }
  let migration = null;
  if (current.major !== target.major) {
    if (transition !== "downgrade" && !allowMajor) {
      fail("major-requires-allow-major");
    }
    migration = validateMigrationBoundary(
      migrationPath ? path.resolve(resolvedRoot, migrationPath) : undefined,
      current,
      target
    );
  }

  const changes = foundationDependencies(packageManifest).map(
    ({ section, name, spec }) => ({
      section,
      name,
      from: spec,
      to: target.raw
    })
  );

  return {
    schemaVersion: 1,
    root: resolvedRoot,
    currentVersion: current.raw,
    targetVersion: target.raw,
    transition,
    migration,
    changes
  };
}

function updatePackageManifest(packageManifest, targetVersion) {
  const next = structuredClone(packageManifest);
  for (const section of DEPENDENCY_SECTIONS) {
    const values = next[section];
    if (!values || typeof values !== "object" || Array.isArray(values)) continue;
    for (const name of Object.keys(values)) {
      if (FOUNDATION_PACKAGE_SET.has(name)) values[name] = targetVersion;
    }
  }
  return next;
}

function sha256(bytes) {
  if (bytes === null) return null;
  return crypto.createHash("sha256").update(bytes).digest("hex");
}

function packageManagerCommand() {
  return {
    command: "npm",
    args: [
      "install",
      "--package-lock-only",
      "--ignore-scripts",
      "--no-audit",
      "--no-fund"
    ]
  };
}

function defaultRunPackageManager(root) {
  const { command, args } = packageManagerCommand();
  const result = spawnSync(
    command,
    args,
    {
      cwd: root,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"]
    }
  );
  if (result.error) {
    fail(`npm-exec:${result.error.code ?? result.error.message}`);
  }
  if (result.status !== 0) {
    const detail = String(result.stderr || result.stdout || "")
      .trim()
      .split("\n")
      .slice(-4)
      .join(" | ");
    fail(`npm-install:${result.status}:${detail}`);
  }
}

function metadataDir(root) {
  const dir = path.join(root, ".datarelay");
  if (fs.existsSync(dir)) {
    const stat = fs.lstatSync(dir);
    if (stat.isSymbolicLink() || !stat.isDirectory()) {
      fail("metadata-dir-unsafe");
    }
  } else {
    fs.mkdirSync(dir, { mode: 0o700 });
  }
  return dir;
}

function receiptPath(root) {
  return path.join(root, ".datarelay", "foundation-upgrade.json");
}

function writeReceipt(root, receipt) {
  const dir = metadataDir(root);
  const text = JSON.stringify(receipt, null, 2) + "\n";
  atomicWrite(receiptPath(root), Buffer.from(text, "utf8"));
}

function removeEmptyDataRelayDir(root) {
  const dir = path.join(root, ".datarelay");
  if (!fs.existsSync(dir)) return;
  const stat = fs.lstatSync(dir);
  if (stat.isSymbolicLink() || !stat.isDirectory()) return;
  if (fs.readdirSync(dir).length === 0) fs.rmdirSync(dir);
}

function withUpgradeLock(root, callback) {
  const dir = metadataDir(root);
  const lock = path.join(dir, "foundation-upgrade.lock");
  let fd;
  try {
    fd = fs.openSync(lock, "wx", 0o600);
  } catch (error) {
    if (error && error.code === "EEXIST") fail("upgrade-lock-held");
    throw error;
  }
  try {
    return callback();
  } finally {
    if (fd !== undefined) fs.closeSync(fd);
    fs.rmSync(lock, { force: true });
    removeEmptyDataRelayDir(root);
  }
}

export function applyUpgrade(options, dependencies = {}) {
  const root = path.resolve(options.root ?? process.cwd());
  const runPackageManager =
    dependencies.runPackageManager ?? defaultRunPackageManager;
  const runDoctor =
    dependencies.runDoctor ?? ((projectRoot) => doctorProject({ root: projectRoot }));

  return withUpgradeLock(root, () => {
    const plan = planUpgrade({ ...options, root });
    if (plan.transition === "noop") {
      return { status: "NOOP", plan, receipt: null };
    }

    const packageFile = path.join(root, "package.json");
    const lockFile = path.join(root, "package-lock.json");
    const oldPackage = readFileState(packageFile);
    const oldLock = readFileState(lockFile);
    if (!oldLock.exists) fail("package-lock-required-for-apply");
    const oldReceipt = readFileState(receiptPath(root));
    const packageText = oldPackage.bytes.toString("utf8");
    const packageManifest = JSON.parse(packageText);
    const nextPackage = updatePackageManifest(packageManifest, plan.targetVersion);

    try {
      writeJsonLike(packageFile, packageText, nextPackage);
      runPackageManager(root);
      const doctor = runDoctor(root);
      if (doctor.foundationVersion !== plan.targetVersion) {
        fail("doctor-target-version-mismatch");
      }

      const newPackage = readFileState(packageFile);
      const newLock = readFileState(lockFile);
      const receipt = {
        schema_version: 1,
        prior_version: plan.currentVersion,
        target_version: plan.targetVersion,
        transition: plan.transition,
        migration_id: plan.migration?.migrationId ?? null,
        package_json_before_sha256: sha256(oldPackage.bytes),
        package_lock_before_sha256: sha256(oldLock.bytes),
        package_json_after_sha256: sha256(newPackage.bytes),
        package_lock_after_sha256: sha256(newLock.bytes),
        lock_file_existed_before: oldLock.exists,
        rollback_command:
          plan.currentVersion.split(".")[0] === plan.targetVersion.split(".")[0]
            ? `datarelay-foundation upgrade --to ${plan.currentVersion} --allow-downgrade --apply`
            : `datarelay-foundation upgrade --to ${plan.currentVersion} --allow-downgrade --migration <reverse-migration.json> --apply`
      };
      writeReceipt(root, receipt);
      return { status: "APPLIED", plan, receipt };
    } catch (error) {
      restoreFileState(packageFile, oldPackage);
      restoreFileState(lockFile, oldLock);
      restoreFileState(receiptPath(root), oldReceipt);
      removeEmptyDataRelayDir(root);
      throw error;
    }
  });
}

export function readRollbackPlan({ root = process.cwd() } = {}) {
  const resolvedRoot = path.resolve(root);
  const file = receiptPath(resolvedRoot);
  const { value: receipt } = readJson(file, "upgrade-receipt");
  if (!receipt || typeof receipt !== "object" || Array.isArray(receipt)) {
    fail("upgrade-receipt-object");
  }
  if (
    receipt.schema_version !== 1 ||
    typeof receipt.prior_version !== "string" ||
    typeof receipt.target_version !== "string"
  ) {
    fail("upgrade-receipt-contract");
  }
  parseVersion(receipt.prior_version, "receipt-prior-version");
  parseVersion(receipt.target_version, "receipt-target-version");

  const currentPackage = readFileState(path.join(resolvedRoot, "package.json"));
  const currentLock = readFileState(path.join(resolvedRoot, "package-lock.json"));
  if (sha256(currentPackage.bytes) !== receipt.package_json_after_sha256) {
    fail("rollback-receipt-stale:package-json");
  }
  if (sha256(currentLock.bytes) !== (receipt.package_lock_after_sha256 ?? null)) {
    fail("rollback-receipt-stale:package-lock");
  }
  const doctor = doctorProject({ root: resolvedRoot });
  if (doctor.foundationVersion !== receipt.target_version) {
    fail("rollback-receipt-stale:foundation-version");
  }

  return {
    schemaVersion: 1,
    currentVersion: receipt.target_version,
    rollbackVersion: receipt.prior_version,
    packageJsonBeforeSha256: receipt.package_json_before_sha256 ?? null,
    packageLockBeforeSha256: receipt.package_lock_before_sha256 ?? null,
    packageJsonAfterSha256: receipt.package_json_after_sha256 ?? null,
    packageLockAfterSha256: receipt.package_lock_after_sha256 ?? null,
    lockFileExistedBefore: receipt.lock_file_existed_before === true,
    command: receipt.rollback_command
  };
}

export const _test = {
  compareVersions,
  classifyTransition,
  parseVersion,
  packageManagerCommand,
  updatePackageManifest
};
