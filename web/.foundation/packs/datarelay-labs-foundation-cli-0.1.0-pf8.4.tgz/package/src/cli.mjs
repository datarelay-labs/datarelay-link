#!/usr/bin/env node
import { doctorProject } from "./doctor.mjs";
import { applyUpgrade, planUpgrade, readRollbackPlan } from "./upgrade.mjs";
import { runCompatibilityLabFromFile } from "./conformance.mjs";

function usage() {
  console.error(
    "usage: datarelay-foundation <doctor|upgrade|rollback-plan|conformance> [options]"
  );
}

function parseOptions(args, allowedFlags) {
  const out = {};
  for (let index = 0; index < args.length; index += 1) {
    const key = args[index];
    if (!allowedFlags.has(key)) throw new Error(`unexpected-argument:${key}`);
    if (["--apply", "--allow-major", "--allow-downgrade"].includes(key)) {
      const name = key.slice(2).replaceAll("-", "_");
      if (Object.hasOwn(out, name)) {
        throw new Error(`duplicate-argument:${key}`);
      }
      out[name] = true;
      continue;
    }
    const value = args[index + 1];
    if (!value || value.startsWith("--")) {
      throw new Error(`missing-value:${key}`);
    }
    const name = key.slice(2).replaceAll("-", "_");
    if (Object.hasOwn(out, name)) {
      throw new Error(`duplicate-argument:${key}`);
    }
    out[name] = value;
    index += 1;
  }
  return out;
}

function printPlan(plan, applying) {
  console.log("FOUNDATION_UPGRADE=" + (applying ? "APPLY" : "PLAN"));
  console.log("CURRENT_VERSION=" + plan.currentVersion);
  console.log("TARGET_VERSION=" + plan.targetVersion);
  console.log("TRANSITION=" + plan.transition);
  console.log("CHANGES=" + plan.changes.length);
  for (const change of plan.changes) {
    console.log(
      `CHANGE=${change.section}:${change.name}:${change.from}->${change.to}`
    );
  }
  if (plan.migration) {
    console.log("MIGRATION_ID=" + plan.migration.migrationId);
  }
}

function printRollback(plan) {
  console.log("FOUNDATION_ROLLBACK_PLAN=PASS");
  console.log("CURRENT_VERSION=" + plan.currentVersion);
  console.log("ROLLBACK_VERSION=" + plan.rollbackVersion);
  console.log("LOCK_FILE_EXISTED_BEFORE=" + (plan.lockFileExistedBefore ? "YES" : "NO"));
  console.log("PACKAGE_JSON_BEFORE_SHA256=" + (plan.packageJsonBeforeSha256 ?? "NONE"));
  console.log("PACKAGE_LOCK_BEFORE_SHA256=" + (plan.packageLockBeforeSha256 ?? "NONE"));
  console.log("ROLLBACK_COMMAND=" + plan.command);
}

const [command, ...args] = process.argv.slice(2);

try {
  if (command === "doctor") {
    const options = parseOptions(args, new Set(["--root", "--manifest"]));
    const result = doctorProject({
      root: options.root,
      manifestPath: options.manifest
    });
    console.log("FOUNDATION_DOCTOR=PASS");
    console.log("FOUNDATION_VERSION=" + result.foundationVersion);
    console.log("FOUNDATION_PACKAGES=" + result.foundationPackages.length);
    console.log("LOCKFILE=" + (result.lockfilePresent ? "PRESENT" : "ABSENT"));
    console.log("PRODUCT_ID=" + result.productId);
    console.log("NAVIGATION_COUNT=" + result.navigationCount);
    console.log("CAPABILITY_COUNT=" + result.capabilityCount);
  } else if (command === "upgrade") {
    const options = parseOptions(
      args,
      new Set([
        "--root",
        "--to",
        "--apply",
        "--allow-major",
        "--allow-downgrade",
        "--migration"
      ])
    );
    if (!options.to) throw new Error("missing-value:--to");
    const upgradeOptions = {
      root: options.root,
      targetVersion: options.to,
      allowMajor: options.allow_major === true,
      allowDowngrade: options.allow_downgrade === true,
      migrationPath: options.migration
    };
    if (options.apply === true) {
      const result = applyUpgrade(upgradeOptions);
      printPlan(result.plan, true);
      console.log("FOUNDATION_UPGRADE_RESULT=" + result.status);
    } else {
      const plan = planUpgrade(upgradeOptions);
      printPlan(plan, false);
      console.log("FOUNDATION_UPGRADE_RESULT=DRY_RUN");
    }
  } else if (command === "rollback-plan") {
    const options = parseOptions(args, new Set(["--root"]));
    printRollback(readRollbackPlan({ root: options.root }));
  } else if (command === "conformance") {
    const options = parseOptions(args, new Set(["--request", "--output"]));
    if (!options.request) throw new Error("missing-value:--request");
    const receipt = runCompatibilityLabFromFile(options.request, {
      outputPath: options.output
    });
    console.log("FOUNDATION_CONFORMANCE=" + receipt.status);
    console.log("FOUNDATION_REVISION=" + receipt.foundation.revision);
    console.log("FOUNDATION_VERSION=" + receipt.foundation.version);
    console.log("CONSUMER_REVISION=" + receipt.consumer.revision);
    console.log("FOUNDATION_SOURCE_UNCHANGED=" + receipt.canonical_foundation_source_unchanged);
    console.log("CONSUMER_SOURCE_UNCHANGED=" + receipt.canonical_consumer_source_unchanged);
    console.log("WORKSPACE_CLEANUP=" + receipt.cleanup);
    if (receipt.status === "FAIL") process.exitCode = 1;
    if (receipt.status === "BLOCKED") process.exitCode = 3;
  } else {
    usage();
    process.exit(2);
  }
} catch (error) {
  const message = error instanceof Error ? error.message : "unknown";
  console.error("FOUNDATION_COMMAND=FAIL");
  console.error("REASON=" + message);
  process.exit(2);
}
