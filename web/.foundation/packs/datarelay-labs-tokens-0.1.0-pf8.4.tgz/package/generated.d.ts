export declare const dataRelayTokens: {
    readonly font: {
        readonly family: {
            readonly ui: {
                readonly $type: "fontFamily";
                readonly $value: readonly ["Inter", "system-ui", "-apple-system", "BlinkMacSystemFont", "Segoe UI", "sans-serif"];
            };
        };
        readonly size: {
            readonly xs: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 12;
                    readonly unit: "px";
                };
            };
            readonly sm: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 13;
                    readonly unit: "px";
                };
            };
            readonly base: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 14;
                    readonly unit: "px";
                };
            };
            readonly lg: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 16;
                    readonly unit: "px";
                };
            };
            readonly xl: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 20;
                    readonly unit: "px";
                };
            };
            readonly "2xl": {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 24;
                    readonly unit: "px";
                };
            };
        };
        readonly weight: {
            readonly regular: {
                readonly $type: "fontWeight";
                readonly $value: 400;
            };
            readonly medium: {
                readonly $type: "fontWeight";
                readonly $value: 500;
            };
            readonly strong: {
                readonly $type: "fontWeight";
                readonly $value: 600;
            };
        };
    };
    readonly radius: {
        readonly control: {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 8;
                readonly unit: "px";
            };
        };
        readonly card: {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 8;
                readonly unit: "px";
            };
        };
        readonly pill: {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 9999;
                readonly unit: "px";
            };
        };
    };
    readonly space: {
        readonly "1": {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 4;
                readonly unit: "px";
            };
        };
        readonly "2": {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 8;
                readonly unit: "px";
            };
        };
        readonly "3": {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 12;
                readonly unit: "px";
            };
        };
        readonly "4": {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 16;
                readonly unit: "px";
            };
        };
        readonly "5": {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 20;
                readonly unit: "px";
            };
        };
        readonly "6": {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 24;
                readonly unit: "px";
            };
        };
        readonly "8": {
            readonly $type: "dimension";
            readonly $value: {
                readonly value: 32;
                readonly unit: "px";
            };
        };
    };
    readonly layout: {
        readonly sidebar: {
            readonly expanded: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 260;
                    readonly unit: "px";
                };
            };
            readonly collapsed: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 57;
                    readonly unit: "px";
                };
            };
        };
        readonly content: {
            readonly max: {
                readonly $type: "dimension";
                readonly $value: {
                    readonly value: 1440;
                    readonly unit: "px";
                };
            };
        };
    };
    readonly brand: {
        readonly mark: {
            readonly $type: "color";
            readonly $value: {
                readonly colorSpace: "srgb";
                readonly components: readonly [0, 0.81568627, 0.51764706];
                readonly hex: "#00d084";
            };
        };
    };
    readonly theme: {
        readonly light: {
            readonly brand: {
                readonly relay: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0, 0.49411765, 0.30980392];
                        readonly hex: "#007e4f";
                    };
                };
                readonly data: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.12156863, 0.16078431, 0.21568627];
                        readonly hex: "#1f2937";
                    };
                };
            };
            readonly surface: {
                readonly page: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.98823529, 0.98823529, 0.98823529];
                        readonly hex: "#fcfcfc";
                    };
                };
                readonly panel: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [1, 1, 1];
                        readonly hex: "#ffffff";
                    };
                };
                readonly section: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.96862745, 0.96862745, 0.96862745];
                        readonly hex: "#f7f7f7";
                    };
                };
                readonly card: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [1, 1, 1];
                        readonly hex: "#ffffff";
                    };
                };
                readonly elevated: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [1, 1, 1];
                        readonly hex: "#ffffff";
                    };
                };
                readonly overlay: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0, 0, 0];
                        readonly alpha: 0.42;
                        readonly hex: "#000000";
                    };
                };
                readonly input: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [1, 1, 1];
                        readonly hex: "#ffffff";
                    };
                };
                readonly hover: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.94509804, 0.94509804, 0.94509804];
                        readonly hex: "#f1f1f1";
                    };
                };
            };
            readonly border: {
                readonly default: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.89803922, 0.90588235, 0.92156863];
                        readonly hex: "#e5e7eb";
                    };
                };
                readonly strong: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.81960784, 0.83529412, 0.85882353];
                        readonly hex: "#d1d5db";
                    };
                };
                readonly divider: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.9254902, 0.9254902, 0.9254902];
                        readonly hex: "#ececec";
                    };
                };
                readonly input: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.50196078, 0.50196078, 0.50196078];
                        readonly hex: "#808080";
                    };
                };
            };
            readonly text: {
                readonly primary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.12156863, 0.16078431, 0.21568627];
                        readonly hex: "#1f2937";
                    };
                };
                readonly secondary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.29411765, 0.33333333, 0.38823529];
                        readonly hex: "#4b5563";
                    };
                };
                readonly muted: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.37647059, 0.40784314, 0.45882353];
                        readonly hex: "#606875";
                    };
                };
                readonly placeholder: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.41960784, 0.44705882, 0.50196078];
                        readonly hex: "#6b7280";
                    };
                };
                readonly inverse: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [1, 1, 1];
                        readonly hex: "#ffffff";
                    };
                };
            };
            readonly action: {
                readonly primary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.14509804, 0.38823529, 0.92156863];
                        readonly hex: "#2563eb";
                    };
                };
                readonly primaryHover: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.11372549, 0.30588235, 0.84705882];
                        readonly hex: "#1d4ed8";
                    };
                };
                readonly secondary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [1, 1, 1];
                        readonly hex: "#ffffff";
                    };
                };
                readonly secondaryHover: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.95294118, 0.95686275, 0.96470588];
                        readonly hex: "#f3f4f6";
                    };
                };
            };
            readonly status: {
                readonly info: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.11372549, 0.30588235, 0.84705882];
                        readonly hex: "#1d4ed8";
                    };
                };
                readonly success: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.01568627, 0.47058824, 0.34117647];
                        readonly hex: "#047857";
                    };
                };
                readonly warning: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.57254902, 0.25098039, 0.05490196];
                        readonly hex: "#92400e";
                    };
                };
                readonly critical: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.70588235, 0.1372549, 0.09411765];
                        readonly hex: "#b42318";
                    };
                };
            };
            readonly focus: {
                readonly ring: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.14509804, 0.38823529, 0.92156863];
                        readonly hex: "#2563eb";
                    };
                };
            };
        };
        readonly dark: {
            readonly brand: {
                readonly relay: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0, 0.81568627, 0.51764706];
                        readonly hex: "#00d084";
                    };
                };
                readonly data: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.96862745, 0.96862745, 0.96862745];
                        readonly hex: "#f7f7f7";
                    };
                };
            };
            readonly surface: {
                readonly page: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.10196078, 0.10196078, 0.10196078];
                        readonly hex: "#1a1a1a";
                    };
                };
                readonly panel: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.14901961, 0.14901961, 0.14901961];
                        readonly hex: "#262626";
                    };
                };
                readonly section: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.13333333, 0.13333333, 0.13333333];
                        readonly hex: "#222222";
                    };
                };
                readonly card: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.14901961, 0.14901961, 0.14901961];
                        readonly hex: "#262626";
                    };
                };
                readonly elevated: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.12156863, 0.12156863, 0.12156863];
                        readonly hex: "#1f1f1f";
                    };
                };
                readonly overlay: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0, 0, 0];
                        readonly alpha: 0.42;
                        readonly hex: "#000000";
                    };
                };
                readonly input: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.17647059, 0.17647059, 0.17647059];
                        readonly hex: "#2d2d2d";
                    };
                };
                readonly hover: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.2, 0.2, 0.2];
                        readonly hex: "#333333";
                    };
                };
            };
            readonly border: {
                readonly default: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.27058824, 0.27058824, 0.27058824];
                        readonly hex: "#454545";
                    };
                };
                readonly strong: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.33333333, 0.33333333, 0.33333333];
                        readonly hex: "#555555";
                    };
                };
                readonly divider: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.21960784, 0.21960784, 0.21960784];
                        readonly hex: "#383838";
                    };
                };
                readonly input: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.50196078, 0.50196078, 0.50196078];
                        readonly hex: "#808080";
                    };
                };
            };
            readonly text: {
                readonly primary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.96862745, 0.96862745, 0.96862745];
                        readonly hex: "#f7f7f7";
                    };
                };
                readonly secondary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.81960784, 0.83529412, 0.85882353];
                        readonly hex: "#d1d5db";
                    };
                };
                readonly muted: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.70196078, 0.70196078, 0.70196078];
                        readonly hex: "#b3b3b3";
                    };
                };
                readonly placeholder: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.70196078, 0.70196078, 0.70196078];
                        readonly hex: "#b3b3b3";
                    };
                };
                readonly inverse: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.06666667, 0.09411765, 0.15294118];
                        readonly hex: "#111827";
                    };
                };
            };
            readonly action: {
                readonly primary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.23137255, 0.50980392, 0.96470588];
                        readonly hex: "#3b82f6";
                    };
                };
                readonly primaryHover: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.37647059, 0.64705882, 0.98039216];
                        readonly hex: "#60a5fa";
                    };
                };
                readonly secondary: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.14901961, 0.14901961, 0.14901961];
                        readonly hex: "#262626";
                    };
                };
                readonly secondaryHover: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.2, 0.2, 0.2];
                        readonly hex: "#333333";
                    };
                };
            };
            readonly status: {
                readonly info: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.37647059, 0.64705882, 0.98039216];
                        readonly hex: "#60a5fa";
                    };
                };
                readonly success: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.20392157, 0.82745098, 0.6];
                        readonly hex: "#34d399";
                    };
                };
                readonly warning: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.96078431, 0.61960784, 0.04313725];
                        readonly hex: "#f59e0b";
                    };
                };
                readonly critical: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.97254902, 0.44313725, 0.44313725];
                        readonly hex: "#f87171";
                    };
                };
            };
            readonly focus: {
                readonly ring: {
                    readonly $type: "color";
                    readonly $value: {
                        readonly colorSpace: "srgb";
                        readonly components: readonly [0.37647059, 0.64705882, 0.98039216];
                        readonly hex: "#60a5fa";
                    };
                };
            };
        };
    };
    readonly $extensions: {
        readonly "run.datarelay.product-foundation": {
            readonly contractVersion: 1;
            readonly dtcgFormat: "2025.10";
        };
    };
};
export type DataRelayTokens = typeof dataRelayTokens;
