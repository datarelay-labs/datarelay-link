/* Generated from DTCG 2025.10-compatible tokens. Do not edit directly. */
export const dataRelayTokens = {
    "font": {
        "family": {
            "ui": {
                "$type": "fontFamily",
                "$value": [
                    "Inter",
                    "system-ui",
                    "-apple-system",
                    "BlinkMacSystemFont",
                    "Segoe UI",
                    "sans-serif"
                ]
            }
        },
        "size": {
            "xs": {
                "$type": "dimension",
                "$value": {
                    "value": 12,
                    "unit": "px"
                }
            },
            "sm": {
                "$type": "dimension",
                "$value": {
                    "value": 13,
                    "unit": "px"
                }
            },
            "base": {
                "$type": "dimension",
                "$value": {
                    "value": 14,
                    "unit": "px"
                }
            },
            "lg": {
                "$type": "dimension",
                "$value": {
                    "value": 16,
                    "unit": "px"
                }
            },
            "xl": {
                "$type": "dimension",
                "$value": {
                    "value": 20,
                    "unit": "px"
                }
            },
            "2xl": {
                "$type": "dimension",
                "$value": {
                    "value": 24,
                    "unit": "px"
                }
            }
        },
        "weight": {
            "regular": {
                "$type": "fontWeight",
                "$value": 400
            },
            "medium": {
                "$type": "fontWeight",
                "$value": 500
            },
            "strong": {
                "$type": "fontWeight",
                "$value": 600
            }
        }
    },
    "radius": {
        "control": {
            "$type": "dimension",
            "$value": {
                "value": 8,
                "unit": "px"
            }
        },
        "card": {
            "$type": "dimension",
            "$value": {
                "value": 8,
                "unit": "px"
            }
        },
        "pill": {
            "$type": "dimension",
            "$value": {
                "value": 9999,
                "unit": "px"
            }
        }
    },
    "space": {
        "1": {
            "$type": "dimension",
            "$value": {
                "value": 4,
                "unit": "px"
            }
        },
        "2": {
            "$type": "dimension",
            "$value": {
                "value": 8,
                "unit": "px"
            }
        },
        "3": {
            "$type": "dimension",
            "$value": {
                "value": 12,
                "unit": "px"
            }
        },
        "4": {
            "$type": "dimension",
            "$value": {
                "value": 16,
                "unit": "px"
            }
        },
        "5": {
            "$type": "dimension",
            "$value": {
                "value": 20,
                "unit": "px"
            }
        },
        "6": {
            "$type": "dimension",
            "$value": {
                "value": 24,
                "unit": "px"
            }
        },
        "8": {
            "$type": "dimension",
            "$value": {
                "value": 32,
                "unit": "px"
            }
        }
    },
    "layout": {
        "sidebar": {
            "expanded": {
                "$type": "dimension",
                "$value": {
                    "value": 260,
                    "unit": "px"
                }
            },
            "collapsed": {
                "$type": "dimension",
                "$value": {
                    "value": 57,
                    "unit": "px"
                }
            }
        },
        "content": {
            "max": {
                "$type": "dimension",
                "$value": {
                    "value": 1440,
                    "unit": "px"
                }
            }
        }
    },
    "brand": {
        "mark": {
            "$type": "color",
            "$value": {
                "colorSpace": "srgb",
                "components": [
                    0,
                    0.81568627,
                    0.51764706
                ],
                "hex": "#00d084"
            }
        }
    },
    "theme": {
        "light": {
            "brand": {
                "relay": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0,
                            0.49411765,
                            0.30980392
                        ],
                        "hex": "#007e4f"
                    }
                },
                "data": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.12156863,
                            0.16078431,
                            0.21568627
                        ],
                        "hex": "#1f2937"
                    }
                }
            },
            "surface": {
                "page": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.98823529,
                            0.98823529,
                            0.98823529
                        ],
                        "hex": "#fcfcfc"
                    }
                },
                "panel": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            1,
                            1,
                            1
                        ],
                        "hex": "#ffffff"
                    }
                },
                "section": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.96862745,
                            0.96862745,
                            0.96862745
                        ],
                        "hex": "#f7f7f7"
                    }
                },
                "card": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            1,
                            1,
                            1
                        ],
                        "hex": "#ffffff"
                    }
                },
                "elevated": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            1,
                            1,
                            1
                        ],
                        "hex": "#ffffff"
                    }
                },
                "overlay": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0,
                            0,
                            0
                        ],
                        "alpha": 0.42,
                        "hex": "#000000"
                    }
                },
                "input": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            1,
                            1,
                            1
                        ],
                        "hex": "#ffffff"
                    }
                },
                "hover": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.94509804,
                            0.94509804,
                            0.94509804
                        ],
                        "hex": "#f1f1f1"
                    }
                }
            },
            "border": {
                "default": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.89803922,
                            0.90588235,
                            0.92156863
                        ],
                        "hex": "#e5e7eb"
                    }
                },
                "strong": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.81960784,
                            0.83529412,
                            0.85882353
                        ],
                        "hex": "#d1d5db"
                    }
                },
                "divider": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.9254902,
                            0.9254902,
                            0.9254902
                        ],
                        "hex": "#ececec"
                    }
                },
                "input": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.50196078,
                            0.50196078,
                            0.50196078
                        ],
                        "hex": "#808080"
                    }
                }
            },
            "text": {
                "primary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.12156863,
                            0.16078431,
                            0.21568627
                        ],
                        "hex": "#1f2937"
                    }
                },
                "secondary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.29411765,
                            0.33333333,
                            0.38823529
                        ],
                        "hex": "#4b5563"
                    }
                },
                "muted": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.37647059,
                            0.40784314,
                            0.45882353
                        ],
                        "hex": "#606875"
                    }
                },
                "placeholder": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.41960784,
                            0.44705882,
                            0.50196078
                        ],
                        "hex": "#6b7280"
                    }
                },
                "inverse": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            1,
                            1,
                            1
                        ],
                        "hex": "#ffffff"
                    }
                }
            },
            "action": {
                "primary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.14509804,
                            0.38823529,
                            0.92156863
                        ],
                        "hex": "#2563eb"
                    }
                },
                "primaryHover": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.11372549,
                            0.30588235,
                            0.84705882
                        ],
                        "hex": "#1d4ed8"
                    }
                },
                "secondary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            1,
                            1,
                            1
                        ],
                        "hex": "#ffffff"
                    }
                },
                "secondaryHover": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.95294118,
                            0.95686275,
                            0.96470588
                        ],
                        "hex": "#f3f4f6"
                    }
                }
            },
            "status": {
                "info": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.11372549,
                            0.30588235,
                            0.84705882
                        ],
                        "hex": "#1d4ed8"
                    }
                },
                "success": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.01568627,
                            0.47058824,
                            0.34117647
                        ],
                        "hex": "#047857"
                    }
                },
                "warning": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.57254902,
                            0.25098039,
                            0.05490196
                        ],
                        "hex": "#92400e"
                    }
                },
                "critical": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.70588235,
                            0.1372549,
                            0.09411765
                        ],
                        "hex": "#b42318"
                    }
                }
            },
            "focus": {
                "ring": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.14509804,
                            0.38823529,
                            0.92156863
                        ],
                        "hex": "#2563eb"
                    }
                }
            }
        },
        "dark": {
            "brand": {
                "relay": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0,
                            0.81568627,
                            0.51764706
                        ],
                        "hex": "#00d084"
                    }
                },
                "data": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.96862745,
                            0.96862745,
                            0.96862745
                        ],
                        "hex": "#f7f7f7"
                    }
                }
            },
            "surface": {
                "page": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.10196078,
                            0.10196078,
                            0.10196078
                        ],
                        "hex": "#1a1a1a"
                    }
                },
                "panel": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.14901961,
                            0.14901961,
                            0.14901961
                        ],
                        "hex": "#262626"
                    }
                },
                "section": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.13333333,
                            0.13333333,
                            0.13333333
                        ],
                        "hex": "#222222"
                    }
                },
                "card": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.14901961,
                            0.14901961,
                            0.14901961
                        ],
                        "hex": "#262626"
                    }
                },
                "elevated": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.12156863,
                            0.12156863,
                            0.12156863
                        ],
                        "hex": "#1f1f1f"
                    }
                },
                "overlay": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0,
                            0,
                            0
                        ],
                        "alpha": 0.42,
                        "hex": "#000000"
                    }
                },
                "input": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.17647059,
                            0.17647059,
                            0.17647059
                        ],
                        "hex": "#2d2d2d"
                    }
                },
                "hover": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.2,
                            0.2,
                            0.2
                        ],
                        "hex": "#333333"
                    }
                }
            },
            "border": {
                "default": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.27058824,
                            0.27058824,
                            0.27058824
                        ],
                        "hex": "#454545"
                    }
                },
                "strong": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.33333333,
                            0.33333333,
                            0.33333333
                        ],
                        "hex": "#555555"
                    }
                },
                "divider": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.21960784,
                            0.21960784,
                            0.21960784
                        ],
                        "hex": "#383838"
                    }
                },
                "input": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.50196078,
                            0.50196078,
                            0.50196078
                        ],
                        "hex": "#808080"
                    }
                }
            },
            "text": {
                "primary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.96862745,
                            0.96862745,
                            0.96862745
                        ],
                        "hex": "#f7f7f7"
                    }
                },
                "secondary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.81960784,
                            0.83529412,
                            0.85882353
                        ],
                        "hex": "#d1d5db"
                    }
                },
                "muted": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.70196078,
                            0.70196078,
                            0.70196078
                        ],
                        "hex": "#b3b3b3"
                    }
                },
                "placeholder": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.70196078,
                            0.70196078,
                            0.70196078
                        ],
                        "hex": "#b3b3b3"
                    }
                },
                "inverse": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.06666667,
                            0.09411765,
                            0.15294118
                        ],
                        "hex": "#111827"
                    }
                }
            },
            "action": {
                "primary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.23137255,
                            0.50980392,
                            0.96470588
                        ],
                        "hex": "#3b82f6"
                    }
                },
                "primaryHover": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.37647059,
                            0.64705882,
                            0.98039216
                        ],
                        "hex": "#60a5fa"
                    }
                },
                "secondary": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.14901961,
                            0.14901961,
                            0.14901961
                        ],
                        "hex": "#262626"
                    }
                },
                "secondaryHover": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.2,
                            0.2,
                            0.2
                        ],
                        "hex": "#333333"
                    }
                }
            },
            "status": {
                "info": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.37647059,
                            0.64705882,
                            0.98039216
                        ],
                        "hex": "#60a5fa"
                    }
                },
                "success": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.20392157,
                            0.82745098,
                            0.6
                        ],
                        "hex": "#34d399"
                    }
                },
                "warning": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.96078431,
                            0.61960784,
                            0.04313725
                        ],
                        "hex": "#f59e0b"
                    }
                },
                "critical": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.97254902,
                            0.44313725,
                            0.44313725
                        ],
                        "hex": "#f87171"
                    }
                }
            },
            "focus": {
                "ring": {
                    "$type": "color",
                    "$value": {
                        "colorSpace": "srgb",
                        "components": [
                            0.37647059,
                            0.64705882,
                            0.98039216
                        ],
                        "hex": "#60a5fa"
                    }
                }
            }
        }
    },
    "$extensions": {
        "run.datarelay.product-foundation": {
            "contractVersion": 1,
            "dtcgFormat": "2025.10"
        }
    }
};
