import { jsx as _jsx } from "react/jsx-runtime";
import { cx } from "./utils.js";
export function StatusBadge({ tone = "neutral", className, ...props }) {
    return _jsx("span", { ...props, className: cx("dr-badge", `dr-badge--${tone}`, className) });
}
