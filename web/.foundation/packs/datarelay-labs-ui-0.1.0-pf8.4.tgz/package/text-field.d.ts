import { type InputHTMLAttributes } from "react";
export type TextFieldProps = Omit<InputHTMLAttributes<HTMLInputElement>, "id"> & {
    id?: string;
    label: string;
    hint?: string;
    error?: string;
};
export declare function TextField({ id: suppliedId, label, hint, error, className, "aria-describedby": callerDescribedBy, "aria-invalid": callerInvalid, ...props }: TextFieldProps): import("react").JSX.Element;
