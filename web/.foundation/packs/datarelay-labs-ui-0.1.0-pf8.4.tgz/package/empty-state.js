import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export function EmptyState({ title, description, action }) {
    return (_jsxs("div", { className: "dr-empty-state", children: [_jsx("div", { className: "dr-empty-state__title", children: title }), description ? _jsx("div", { className: "dr-empty-state__description", children: description }) : null, action ? _jsx("div", { className: "dr-empty-state__action", children: action }) : null] }));
}
