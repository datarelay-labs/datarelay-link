import type { HTMLAttributes, ReactNode } from "react";
export type CardProps = HTMLAttributes<HTMLDivElement> & {
    title?: ReactNode;
    description?: ReactNode;
    actions?: ReactNode;
};
export declare function Card({ title, description, actions, className, children, ...props }: CardProps): import("react").JSX.Element;
