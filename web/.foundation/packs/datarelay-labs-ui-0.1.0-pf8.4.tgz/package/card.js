import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { cx } from "./utils.js";
export function Card({ title, description, actions, className, children, ...props }) {
    return (_jsxs("div", { ...props, className: cx("dr-card", className), children: [title || description || actions ? (_jsxs("div", { className: "dr-card__header", children: [_jsxs("div", { className: "dr-card__heading", children: [title ? _jsx("div", { className: "dr-card__title", children: title }) : null, description ? _jsx("div", { className: "dr-card__description", children: description }) : null] }), actions ? _jsx("div", { className: "dr-card__actions", children: actions }) : null] })) : null, _jsx("div", { className: "dr-card__body", children: children })] }));
}
