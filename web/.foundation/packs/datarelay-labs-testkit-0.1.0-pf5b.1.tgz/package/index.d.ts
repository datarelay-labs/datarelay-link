export { verifyCapabilityProjection } from "./capability";
export type { CapabilityExpectation } from "./capability";
export { verifyAuthAdapter } from "./auth";
export type { AuthConformanceFixture } from "./auth";
export { verifySessionRevocationDelegation } from "./session";
export { verifyJobProjection, verifyMutationEvidence } from "./operations";
export { verifyLifecycleCapabilitySeparation } from "./separation";
export type { ConformanceFinding, ConformanceReport } from "./types";
