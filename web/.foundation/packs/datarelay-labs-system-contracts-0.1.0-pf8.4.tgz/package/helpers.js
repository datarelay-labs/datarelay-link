export function capabilityInteractive(availability) {
    return availability === "supported";
}
export function capabilityVisible(availability) {
    return availability !== "unavailable";
}
export function jobTerminal(state) {
    return state === "SUCCEEDED" || state === "FAILED" || state === "CANCELLED";
}
export function previewNeedsExplicitConfirmation(preview) {
    if (!preview?.effects)
        return false;
    const confirmationEffects = [
        "reconnect_required",
        "restart_required",
        "destructive",
        "security_sensitive"
    ];
    return preview.effects.some((effect) => confirmationEffects.includes(effect));
}
