import { STANDARD_ADMINISTRATION_TASKS, effectiveAdministrationAvailability, validateAdministrationHub } from "@datarelay-labs/system-admin-ui";
import { report } from "./types.js";
const STANDARD_BY_ID = new Map(STANDARD_ADMINISTRATION_TASKS.map((task) => [task.id, task]));
function routePath(input) {
    return input.split(/[?#]/, 1)[0] ?? "";
}
function validRouteInventory(value) {
    return Array.isArray(value) && value.every((entry) => typeof entry === "string" &&
        entry.startsWith("/") &&
        !entry.startsWith("//") &&
        !/\s/.test(entry));
}
function validActionInventory(value) {
    return Array.isArray(value) && value.every((entry) => typeof entry === "string" && /^[a-z][a-z0-9._-]*$/.test(entry));
}
/** Fail closed, return stable finding IDs, never rewrite the product authority. */
export function verifyAdministrationConsumer(evidence) {
    const findings = [];
    if (!evidence || typeof evidence !== "object" || !evidence.composition) {
        return report([{ id: "ADMIN_EVIDENCE_INVALID", message: "Consumer composition is required." }]);
    }
    const { composition, registeredPaths, registeredActionIds, requiredCoreTaskIds } = evidence;
    if (!validRouteInventory(registeredPaths)) {
        findings.push({
            id: "ADMIN_NAVIGATION_INVENTORY_MISSING",
            message: "A product-owned absolute-path route inventory is required."
        });
    }
    if (!validActionInventory(registeredActionIds)) {
        findings.push({
            id: "ADMIN_ACTION_INVENTORY_MISSING",
            message: "A product-owned action registry inventory is required."
        });
    }
    try {
        validateAdministrationHub(composition);
    }
    catch {
        // The hub validator also checks namespaced extensions, duplicate targets,
        // missing targets, unknown groups and malformed task IDs. Fail closed.
        findings.push({
            id: "ADMIN_COMPOSITION_INVALID",
            message: "Consumer AdministrationHub composition violates shared invariants."
        });
        return report(findings);
    }
    const paths = validRouteInventory(registeredPaths)
        ? new Set(registeredPaths.map(routePath))
        : null;
    const actions = validActionInventory(registeredActionIds)
        ? new Set(registeredActionIds)
        : null;
    for (const task of composition.tasks) {
        const canonical = STANDARD_BY_ID.get(task.id);
        if (!canonical) {
            findings.push({
                id: "ADMIN_CORE_UNKNOWN",
                message: `Product ${composition.productId} declares unknown core Administration task ${task.id}.`
            });
        }
        else {
            if (task.label !== canonical.label || task.description !== canonical.description) {
                findings.push({
                    id: "ADMIN_CORE_METADATA_DRIFT",
                    message: `Shared Administration label/description differs for ${task.id}.`
                });
            }
            if (task.groupId !== canonical.groupId) {
                findings.push({
                    id: "ADMIN_CORE_GROUP_DRIFT",
                    message: `Shared Administration group differs for ${task.id}.`
                });
            }
        }
    }
    if (requiredCoreTaskIds !== undefined) {
        if (!Array.isArray(requiredCoreTaskIds) ||
            requiredCoreTaskIds.some((id) => !STANDARD_BY_ID.has(id)) ||
            new Set(requiredCoreTaskIds).size !== requiredCoreTaskIds.length) {
            findings.push({
                id: "ADMIN_REQUIREMENTS_INVALID",
                message: "Required Administration task IDs must be unique canonical core task IDs."
            });
        }
        else {
            const byId = new Map(composition.tasks.map((task) => [task.id, task]));
            for (const id of requiredCoreTaskIds) {
                const task = byId.get(id);
                if (!task) {
                    findings.push({ id: "ADMIN_REQUIRED_CORE_MISSING", message: `Required task ${id} is absent.` });
                }
                else if (effectiveAdministrationAvailability(task) === "unavailable") {
                    findings.push({
                        id: "ADMIN_REQUIRED_CORE_UNAVAILABLE",
                        message: `Required task ${id} has no available user-facing action.`
                    });
                }
            }
        }
    }
    const allTasks = [
        ...composition.tasks,
        ...(composition.extensionGroups ?? []).flatMap((group) => [...group.tasks])
    ];
    for (const task of allTasks) {
        if (task.availability === "unavailable" && task.access === "manage") {
            findings.push({
                id: "ADMIN_CAPABILITY_CONTRADICTION",
                message: `Unavailable task ${task.id} cannot advertise management access.`
            });
        }
        // Disabled and forbidden tasks need no navigable destination. Their UI
        // must never expose an action: the AdministrationHub enforces that rule.
        if (effectiveAdministrationAvailability(task) === "unavailable")
            continue;
        if (task.target?.kind === "path" && paths && !paths.has(routePath(task.target.path))) {
            findings.push({
                id: "ADMIN_TARGET_UNREGISTERED",
                message: `Task ${task.id} references a path missing from the consumer route registry.`
            });
        }
        if (task.target?.kind === "action" && actions && !actions.has(task.target.actionId)) {
            findings.push({
                id: "ADMIN_TARGET_UNREGISTERED",
                message: `Task ${task.id} references an action missing from the consumer action registry.`
            });
        }
    }
    return report(findings);
}
