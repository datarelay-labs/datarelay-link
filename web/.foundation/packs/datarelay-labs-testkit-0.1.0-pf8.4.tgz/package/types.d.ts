export type ConformanceFinding = {
    id: string;
    message: string;
};
export type ConformanceReport = {
    ok: boolean;
    findings: readonly ConformanceFinding[];
};
export declare function report(findings: readonly ConformanceFinding[]): ConformanceReport;
