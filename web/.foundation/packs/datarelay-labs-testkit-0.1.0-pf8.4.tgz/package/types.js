export function report(findings) {
    return { ok: findings.length === 0, findings };
}
