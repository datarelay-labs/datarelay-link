import { capabilityInteractive, capabilityVisible } from "@datarelay-labs/system-contracts";
import { report } from "./types.js";
export function verifyCapabilityProjection(capabilities, expectations) {
    const findings = [];
    const byId = new Map(capabilities.map((capability) => [capability.id, capability]));
    for (const expected of expectations) {
        const capability = byId.get(expected.id);
        if (!capability) {
            findings.push({
                id: "CAPABILITY_MISSING",
                message: `Capability ${expected.id} is missing.`
            });
            continue;
        }
        const visible = capabilityVisible(capability.availability);
        const interactive = capabilityInteractive(capability.availability);
        if (visible !== expected.visible) {
            findings.push({
                id: "CAPABILITY_VISIBILITY_MISMATCH",
                message: `${expected.id} visible=${visible}, expected=${expected.visible}.`
            });
        }
        if (interactive !== expected.interactive) {
            findings.push({
                id: "CAPABILITY_INTERACTION_MISMATCH",
                message: `${expected.id} interactive=${interactive}, expected=${expected.interactive}.`
            });
        }
    }
    return report(findings);
}
