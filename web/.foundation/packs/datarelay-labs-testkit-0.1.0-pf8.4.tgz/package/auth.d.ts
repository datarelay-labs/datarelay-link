import type { AuthAdapter } from "@datarelay-labs/auth-ui";
import { type ConformanceReport } from "./types";
export type AuthConformanceFixture = {
    username: string;
    password: string;
};
export declare function verifyAuthAdapter(adapter: AuthAdapter, fixture: AuthConformanceFixture): Promise<ConformanceReport>;
