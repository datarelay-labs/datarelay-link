import { type AdministrationHubComposition, type StandardAdministrationTaskId } from "@datarelay-labs/system-admin-ui";
import { type ConformanceReport } from "./types";
/**
 * A purely structural preflight against product-declared navigation/action
 * inventories. Both inventories MUST be collected from the consumer itself.
 * This does not probe the browser, prove backend RBAC or authorize operations.
 */
export type AdministrationConsumerEvidence = {
    composition: AdministrationHubComposition;
    registeredPaths: readonly string[];
    registeredActionIds: readonly string[];
    /** Consumer-owned mandatory workflows; optional unsupported tasks stay optional. */
    requiredCoreTaskIds?: readonly StandardAdministrationTaskId[];
};
/** Fail closed, return stable finding IDs, never rewrite the product authority. */
export declare function verifyAdministrationConsumer(evidence: AdministrationConsumerEvidence): ConformanceReport;
