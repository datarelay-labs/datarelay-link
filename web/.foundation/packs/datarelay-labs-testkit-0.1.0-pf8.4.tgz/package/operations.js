import { jobTerminal, previewNeedsExplicitConfirmation } from "@datarelay-labs/system-contracts";
import { report } from "./types.js";
export function verifyJobProjection(job) {
    const findings = [];
    if (typeof job.progressPercent === "number" &&
        (job.progressPercent < 0 || job.progressPercent > 100)) {
        findings.push({
            id: "JOB_PROGRESS_OUT_OF_RANGE",
            message: "Job progressPercent must be between 0 and 100."
        });
    }
    if (job.state === "FAILED" && !job.error) {
        findings.push({
            id: "JOB_FAILURE_WITHOUT_ERROR",
            message: "FAILED jobs must expose a stable adapter error."
        });
    }
    if (jobTerminal(job.state) && job.cancellable === true) {
        findings.push({
            id: "JOB_TERMINAL_CANCELLABLE",
            message: "Terminal jobs must not remain cancellable."
        });
    }
    return report(findings);
}
export function verifyMutationEvidence(preview, outcome) {
    const findings = [];
    if (previewNeedsExplicitConfirmation(preview) && !preview?.supported) {
        findings.push({
            id: "MUTATION_DISRUPTIVE_PREVIEW_UNSUPPORTED",
            message: "A disruptive preview cannot simultaneously be marked unsupported."
        });
    }
    if (!outcome.effective && !outcome.job && !outcome.audit) {
        findings.push({
            id: "MUTATION_NO_READBACK_OR_JOB",
            message: "Mutation outcome must expose effective read-back, a job, or an audit reference."
        });
    }
    return report(findings);
}
