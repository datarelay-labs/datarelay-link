"""Product-neutral operational-backup metadata and restore-readiness evidence.

The package NEVER opens or creates a backup, touches a database, decrypts
content, validates real artifact bytes or executes a restore. Each product
owns authoritative backup/restore verification and privileged apply.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import re

_REF = re.compile(r"[a-z][a-z0-9_.-]{0,95}", re.ASCII)
_SHA256 = re.compile(r"[0-9a-f]{64}", re.ASCII)


def _ref(value: str, name: str) -> None:
    if not isinstance(value, str) or _REF.fullmatch(value) is None:
        raise ValueError("invalid " + name)


def _int(value: int | None, name: str, start: int = 0, max_value: int = 2**63 - 1) -> None:
    if value is not None and (type(value) is not int or not start <= value <= max_value):
        raise ValueError("invalid " + name)


class BackupKind(str, Enum):
    CONFIGURATION_EXPORT = "configuration_export"
    DISASTER_RECOVERY = "disaster_recovery"


class BackupState(str, Enum):
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    INCOMPLETE = "incomplete"


@dataclass(frozen=True)
class BackupEvidence:
    """Opaque product-owned receipt, with no artifact path/body or secrets."""
    product_ref: str
    backup_ref: str
    revision_ref: str
    kind: BackupKind
    state: BackupState
    created_at: int
    artifact_bytes: int
    archive_sha256: str
    encrypted_at_rest: bool
    restore_drill_verified_at: int | None = None

    def __post_init__(self) -> None:
        for name in ("product_ref", "backup_ref", "revision_ref"):
            _ref(getattr(self, name), name)
        if type(self.kind) is not BackupKind or type(self.state) is not BackupState:
            raise ValueError("invalid backup kind or state")
        _int(self.created_at, "backup created_at")
        _int(self.artifact_bytes, "backup archive size", 0, 2**60)
        if not isinstance(self.archive_sha256, str) or _SHA256.fullmatch(self.archive_sha256) is None:
            raise ValueError("invalid backup sha256")
        if type(self.encrypted_at_rest) is not bool:
            raise ValueError("invalid backup encryption status")
        _int(self.restore_drill_verified_at, "restore verification time")
        if (
            self.restore_drill_verified_at is not None
            and self.restore_drill_verified_at < self.created_at
        ):
            raise ValueError("restore proof predates backup")


@dataclass(frozen=True)
class BackupPolicy:
    schedule_seconds: int = 86400
    max_acceptable_age_seconds: int = 172800
    keep_last: int = 7
    max_restore_proof_age_seconds: int = 30 * 86400
    require_encryption: bool = True
    require_restore_drill: bool = True

    def __post_init__(self) -> None:
        _int(self.schedule_seconds, "backup schedule", 3600, 365 * 86400)
        _int(self.max_acceptable_age_seconds, "backup acceptable age",
             self.schedule_seconds, 3650 * 86400)
        _int(self.keep_last, "backup retention count", 1, 365)
        _int(self.max_restore_proof_age_seconds, "restore proof age", 3600, 3650 * 86400)
        if type(self.require_encryption) is not bool or type(self.require_restore_drill) is not bool:
            raise ValueError("invalid backup security requirement")


class BackupProblem(str, Enum):
    WRONG_BACKUP_KIND = "wrong_backup_kind"
    NOT_COMPLETE = "not_complete"
    ZERO_LENGTH = "zero_length"
    UNENCRYPTED = "unencrypted"
    FUTURE_EVIDENCE = "future_evidence"
    OVERDUE = "overdue"
    RESTORE_NOT_VERIFIED = "restore_not_verified"
    RESTORE_EVIDENCE_STALE = "restore_evidence_stale"


@dataclass(frozen=True)
class BackupAssessment:
    healthy: bool
    problems: tuple[BackupProblem, ...]
    next_scheduled_at: int
    keep_last: int
    backup_ref: str


def assess_backup(
    backup: BackupEvidence,
    *,
    now: int,
    policy: BackupPolicy = BackupPolicy(),
    operational_recovery_required: bool = True,
) -> BackupAssessment:
    """A *metadata* assessment only; it cannot prove restore succeeded."""
    _int(now, "backup evaluation time")
    if not isinstance(backup, BackupEvidence) or not isinstance(policy, BackupPolicy):
        raise ValueError("invalid backup evidence/policy")
    if type(operational_recovery_required) is not bool:
        raise ValueError("invalid recovery requirement")
    problems: list[BackupProblem] = []
    if operational_recovery_required and backup.kind is not BackupKind.DISASTER_RECOVERY:
        problems.append(BackupProblem.WRONG_BACKUP_KIND)
    if backup.state is not BackupState.SUCCEEDED:
        problems.append(BackupProblem.NOT_COMPLETE)
    if backup.artifact_bytes == 0:
        problems.append(BackupProblem.ZERO_LENGTH)
    if policy.require_encryption and not backup.encrypted_at_rest:
        problems.append(BackupProblem.UNENCRYPTED)
    if backup.created_at > now + 30 or (
        backup.restore_drill_verified_at is not None and backup.restore_drill_verified_at > now + 30
    ):
        problems.append(BackupProblem.FUTURE_EVIDENCE)
    if now - backup.created_at >= policy.max_acceptable_age_seconds:
        problems.append(BackupProblem.OVERDUE)
    if policy.require_restore_drill:
        if backup.restore_drill_verified_at is None:
            problems.append(BackupProblem.RESTORE_NOT_VERIFIED)
        elif now - backup.restore_drill_verified_at >= policy.max_restore_proof_age_seconds:
            problems.append(BackupProblem.RESTORE_EVIDENCE_STALE)
    return BackupAssessment(
        healthy=not problems, problems=tuple(problems),
        next_scheduled_at=backup.created_at + policy.schedule_seconds,
        keep_last=policy.keep_last, backup_ref=backup.backup_ref,
    )


@dataclass(frozen=True)
class RestoreEvidence:
    expected_product_ref: str
    expected_backup_revision: str
    current_product_supports_restore: bool = False
    actor_authorized: bool = False
    recent_mfa_verified: bool = False
    artifact_integrity_verified: bool = False
    compatible_schema_verified: bool = False
    isolated_restore_drill_passed: bool = False
    pre_restore_backup_verified: bool = False
    rollback_ready: bool = False
    offline_recovery_ready: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        _ref(self.expected_product_ref, "expected product")
        _ref(self.expected_backup_revision, "expected backup revision")
        for name in (
            "current_product_supports_restore", "actor_authorized",
            "recent_mfa_verified", "artifact_integrity_verified",
            "compatible_schema_verified", "isolated_restore_drill_passed",
            "pre_restore_backup_verified", "rollback_ready",
            "offline_recovery_ready", "audit_ready",
        ):
            if type(getattr(self, name)) is not bool:
                raise ValueError("invalid restore evidence")


class RestoreBlocker(str, Enum):
    WRONG_PRODUCT = "wrong_product"
    STALE_BACKUP_REVISION = "stale_backup_revision"
    NOT_OPERATIONAL_BACKUP = "not_operational_backup"
    INCOMPLETE_BACKUP = "incomplete_backup"
    UNENCRYPTED_BACKUP = "unencrypted_backup"
    RESTORE_PROOF_MISSING = "restore_proof_missing"
    UNSUPPORTED = "unsupported"
    PERMISSION_DENIED = "permission_denied"
    MFA_REQUIRED = "mfa_required"
    INTEGRITY_UNVERIFIED = "integrity_unverified"
    SCHEMA_UNVERIFIED = "schema_unverified"
    RESTORE_DRILL_MISSING = "restore_drill_missing"
    CURRENT_BACKUP_MISSING = "current_backup_missing"
    ROLLBACK_NOT_READY = "rollback_not_ready"
    OFFLINE_RECOVERY_REQUIRED = "offline_recovery_required"
    AUDIT_UNAVAILABLE = "audit_unavailable"


@dataclass(frozen=True)
class RestorePreview:
    product_ref: str
    backup_ref: str
    blockers: tuple[RestoreBlocker, ...]
    may_submit_to_product_authority: bool
    product_apply_required: bool = True


def preview_restore(
    backup: BackupEvidence,
    evidence: RestoreEvidence,
) -> RestorePreview:
    """Read-only recovery preflight — not permission to restore or decrypt."""
    if not isinstance(backup, BackupEvidence) or not isinstance(evidence, RestoreEvidence):
        raise ValueError("invalid restore request")
    problems: list[RestoreBlocker] = []
    if evidence.expected_product_ref != backup.product_ref:
        problems.append(RestoreBlocker.WRONG_PRODUCT)
    if evidence.expected_backup_revision != backup.revision_ref:
        problems.append(RestoreBlocker.STALE_BACKUP_REVISION)
    if backup.kind is not BackupKind.DISASTER_RECOVERY:
        problems.append(RestoreBlocker.NOT_OPERATIONAL_BACKUP)
    if backup.state is not BackupState.SUCCEEDED or backup.artifact_bytes == 0:
        problems.append(RestoreBlocker.INCOMPLETE_BACKUP)
    if not backup.encrypted_at_rest:
        problems.append(RestoreBlocker.UNENCRYPTED_BACKUP)
    if backup.restore_drill_verified_at is None:
        problems.append(RestoreBlocker.RESTORE_PROOF_MISSING)
    if not evidence.current_product_supports_restore:
        problems.append(RestoreBlocker.UNSUPPORTED)
    if not evidence.actor_authorized:
        problems.append(RestoreBlocker.PERMISSION_DENIED)
    if not evidence.recent_mfa_verified:
        problems.append(RestoreBlocker.MFA_REQUIRED)
    if not evidence.artifact_integrity_verified:
        problems.append(RestoreBlocker.INTEGRITY_UNVERIFIED)
    if not evidence.compatible_schema_verified:
        problems.append(RestoreBlocker.SCHEMA_UNVERIFIED)
    if not evidence.isolated_restore_drill_passed:
        problems.append(RestoreBlocker.RESTORE_DRILL_MISSING)
    if not evidence.pre_restore_backup_verified:
        problems.append(RestoreBlocker.CURRENT_BACKUP_MISSING)
    if not evidence.rollback_ready:
        problems.append(RestoreBlocker.ROLLBACK_NOT_READY)
    if not evidence.offline_recovery_ready:
        problems.append(RestoreBlocker.OFFLINE_RECOVERY_REQUIRED)
    if not evidence.audit_ready:
        problems.append(RestoreBlocker.AUDIT_UNAVAILABLE)
    return RestorePreview(
        product_ref=backup.product_ref, backup_ref=backup.backup_ref,
        blockers=tuple(problems), may_submit_to_product_authority=not problems,
    )
