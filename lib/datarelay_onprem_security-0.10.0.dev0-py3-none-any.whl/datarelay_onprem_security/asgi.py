"""Optional dependency-free ASGI Web+management API ingress guard.

Place OUTSIDE every protected HTTP and WebSocket route including static files.
The product must supply the effective policy and ensure ASGI scope.client
is the real socket peer (not previously rewritten from spoofable headers).
"""
from __future__ import annotations

from typing import Any, Awaitable, Callable

from .acl import ManagementPolicy, authorize_management, canonical_network

ASGIReceive = Callable[[], Awaitable[dict[str, Any]]]
ASGISend = Callable[[dict[str, Any]], Awaitable[None]]
ASGIApp = Callable[[dict[str, Any], ASGIReceive, ASGISend], Awaitable[None]]


class WebManagementAclGuard:
    def __init__(
        self,
        app: ASGIApp,
        *,
        read_effective_policy: Callable[[], ManagementPolicy | None],
        trusted_proxy_cidrs: tuple[str, ...] = (),
    ) -> None:
        self.app = app
        self.read_effective_policy = read_effective_policy
        # Validate trusted proxy configuration at boot; /0 is not accepted.
        self.trusted_proxy_cidrs = tuple(canonical_network(v) for v in trusted_proxy_cidrs)

    async def __call__(self, scope: dict[str, Any], receive: ASGIReceive, send: ASGISend) -> None:
        if scope.get("type") not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        peer = scope.get("client")
        source = peer[0] if isinstance(peer, (tuple, list)) and peer else None
        xff = None
        try:
            for name, value in scope.get("headers", []):
                if name.lower() == b"x-forwarded-for":
                    # Multiple headers are ambiguous: fail closed rather than
                    # letting a reverse proxy select an attacker-controlled one.
                    if xff is not None:
                        raise ValueError("duplicate forwarded header")
                    xff = value.decode("ascii")
            effective = self.read_effective_policy()
            verdict = authorize_management(
                effective, "web", direct_peer=source,
                x_forwarded_for=xff, trusted_proxy_cidrs=self.trusted_proxy_cidrs,
            )
            allowed = verdict.allowed
        except Exception:
            allowed = False

        if allowed:
            await self.app(scope, receive, send)
            return
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
        else:
            await send({
                "type": "http.response.start",
                "status": 403,
                "headers": [(b"content-type", b"application/json"), (b"cache-control", b"no-store")],
            })
            await send({"type": "http.response.body", "body": b'{"detail":"access denied"}'})
