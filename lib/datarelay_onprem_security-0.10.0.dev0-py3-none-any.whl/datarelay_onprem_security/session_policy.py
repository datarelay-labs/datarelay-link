"""Product-neutral password, login-throttle and user-session admission rules.

Pure validation only: never verifies/stores password hashes, grants roles,
issues JWT/cookies, reads a database, modifies firewall rules or invalidates
sessions. Each product persists counters and token epochs atomically.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import unicodedata


def _bounded_int(value: int, label: str, minimum: int, maximum: int) -> None:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError("invalid " + label)


class PasswordIssue(str, Enum):
    MISSING = "missing"
    TOO_SHORT = "too_short"
    TOO_LONG = "too_long"
    CONTROL_CHARACTER = "control_character"


@dataclass(frozen=True)
class PasswordPolicy:
    minimum_length: int = 12
    maximum_length: int = 256

    def __post_init__(self) -> None:
        _bounded_int(self.minimum_length, "password minimum", 8, 256)
        _bounded_int(self.maximum_length, "password maximum", self.minimum_length, 1024)


@dataclass(frozen=True)
class PasswordAssessment:
    accepted: bool
    issues: tuple[PasswordIssue, ...] = ()


def evaluate_new_password(value: str, policy: PasswordPolicy = PasswordPolicy()) -> PasswordAssessment:
    """Check *new* passwords only. Products keep their own hashing/migration.

    Never trim or normalize a supplied password silently, and never echo it
    in the result. This is an additive minimum, not an automatic replacement
    for stronger product-native password requirements.
    """
    if not isinstance(value, str):
        return PasswordAssessment(False, (PasswordIssue.MISSING,))
    problems = []
    if not value or not value.strip():
        problems.append(PasswordIssue.MISSING)
    if len(value) < policy.minimum_length:
        problems.append(PasswordIssue.TOO_SHORT)
    if len(value) > policy.maximum_length:
        problems.append(PasswordIssue.TOO_LONG)
    if any(unicodedata.category(c).startswith("C") for c in value):
        problems.append(PasswordIssue.CONTROL_CHARACTER)
    return PasswordAssessment(not problems, tuple(problems))


def stricter_password_policy(first: PasswordPolicy, second: PasswordPolicy) -> PasswordPolicy:
    """Combine constraints without weakening either product or Foundation."""
    minimum = max(first.minimum_length, second.minimum_length)
    maximum = min(first.maximum_length, second.maximum_length)
    if maximum < minimum:
        raise ValueError("incompatible password policies")
    return PasswordPolicy(minimum, maximum)


@dataclass(frozen=True)
class LoginThrottlePolicy:
    max_failures: int = 5
    window_seconds: int = 300
    lockout_seconds: int = 900

    def __post_init__(self) -> None:
        _bounded_int(self.max_failures, "max login failures", 1, 100)
        _bounded_int(self.window_seconds, "login window", 30, 86400)
        _bounded_int(self.lockout_seconds, "login lockout", 30, 86400)


@dataclass(frozen=True)
class LoginAttemptSnapshot:
    failed_attempts: int = 0
    window_started_at: int | None = None
    locked_until: int | None = None

    def __post_init__(self) -> None:
        _bounded_int(self.failed_attempts, "login attempts", 0, 1000000)
        for field_name in ("window_started_at", "locked_until"):
            value = getattr(self, field_name)
            if value is not None:
                _bounded_int(value, field_name, 0, 2 ** 63 - 1)
        if self.failed_attempts and self.window_started_at is None:
            raise ValueError("nonzero failures require an authoritative window")


class LoginDisposition(str, Enum):
    ALLOW = "allow"
    RATE_LIMITED = "rate_limited"
    LOCKED = "locked"
    INVALID_EVIDENCE = "invalid_evidence"


def assess_login_attempt(
    snapshot: LoginAttemptSnapshot,
    policy: LoginThrottlePolicy = LoginThrottlePolicy(),
    *,
    now: int,
) -> LoginDisposition:
    """Admission based on authoritative account+source counters.

    Products MUST update counters and locks transactionally; concurrent
    attempts cannot rely on this read-only projection alone. The endpoint
    should return the same generic error regardless of username existence.
    """
    _bounded_int(now, "timestamp", 0, 2 ** 63 - 1)
    if snapshot.locked_until is not None and snapshot.locked_until > now:
        return LoginDisposition.LOCKED
    if snapshot.failed_attempts:
        started = snapshot.window_started_at
        if started is None or started > now + 30:
            return LoginDisposition.INVALID_EVIDENCE
        if now - started < policy.window_seconds and snapshot.failed_attempts >= policy.max_failures:
            return LoginDisposition.RATE_LIMITED
    return LoginDisposition.ALLOW


@dataclass(frozen=True)
class SessionPolicy:
    idle_timeout_seconds: int = 1800
    absolute_lifetime_seconds: int = 43200
    max_concurrent_sessions: int = 5
    clock_skew_seconds: int = 30

    def __post_init__(self) -> None:
        _bounded_int(self.idle_timeout_seconds, "idle session timeout", 60, 86400)
        _bounded_int(
            self.absolute_lifetime_seconds, "absolute session timeout",
            self.idle_timeout_seconds, 365 * 86400,
        )
        _bounded_int(self.max_concurrent_sessions, "max sessions", 1, 100)
        _bounded_int(self.clock_skew_seconds, "session clock skew", 0, 300)


@dataclass(frozen=True)
class SessionEvidence:
    """Server-read authoritative fields, NEVER parsed from client JWT claims alone."""
    created_at: int
    last_seen_at: int
    auth_epoch: int
    current_auth_epoch: int
    user_enabled: bool = True
    revoked: bool = False
    mfa_required: bool = False
    mfa_verified_at: int | None = None

    def __post_init__(self) -> None:
        for key in ("created_at", "last_seen_at", "auth_epoch", "current_auth_epoch"):
            _bounded_int(getattr(self, key), key, 0, 2 ** 63 - 1)
        if self.mfa_verified_at is not None:
            _bounded_int(self.mfa_verified_at, "mfa verification time", 0, 2 ** 63 - 1)
        for key in ("user_enabled", "revoked", "mfa_required"):
            if type(getattr(self, key)) is not bool:
                raise ValueError("invalid session boolean field")


class SessionReason(str, Enum):
    ACCEPTED = "accepted"
    NOT_AUTHENTICATED = "not_authenticated"
    INACTIVE_USER = "inactive_user"
    REVOKED = "revoked"
    STALE_AUTH_EPOCH = "stale_auth_epoch"
    INVALID_EVIDENCE = "invalid_evidence"
    ABSOLUTE_EXPIRED = "absolute_expired"
    IDLE_EXPIRED = "idle_expired"
    MFA_REQUIRED = "mfa_required"


@dataclass(frozen=True)
class SessionDecision:
    allowed: bool
    reason: SessionReason


def assess_session(
    session: SessionEvidence | None,
    *,
    now: int,
    policy: SessionPolicy = SessionPolicy(),
) -> SessionDecision:
    """Admit only fully authenticated sessions; never issue or refresh tokens."""
    _bounded_int(now, "timestamp", 0, 2 ** 63 - 1)
    if session is None:
        return SessionDecision(False, SessionReason.NOT_AUTHENTICATED)
    if not session.user_enabled:
        return SessionDecision(False, SessionReason.INACTIVE_USER)
    if session.revoked:
        return SessionDecision(False, SessionReason.REVOKED)
    if session.auth_epoch != session.current_auth_epoch:
        return SessionDecision(False, SessionReason.STALE_AUTH_EPOCH)
    if (
        session.created_at > now + policy.clock_skew_seconds
        or session.last_seen_at > now + policy.clock_skew_seconds
        or session.last_seen_at < session.created_at
    ):
        return SessionDecision(False, SessionReason.INVALID_EVIDENCE)
    if session.mfa_verified_at is not None and (
        session.mfa_verified_at < session.created_at
        or session.mfa_verified_at > now + policy.clock_skew_seconds
    ):
        return SessionDecision(False, SessionReason.INVALID_EVIDENCE)
    if now - session.created_at >= policy.absolute_lifetime_seconds:
        return SessionDecision(False, SessionReason.ABSOLUTE_EXPIRED)
    if now - session.last_seen_at >= policy.idle_timeout_seconds:
        return SessionDecision(False, SessionReason.IDLE_EXPIRED)
    if session.mfa_required and session.mfa_verified_at is None:
        return SessionDecision(False, SessionReason.MFA_REQUIRED)
    return SessionDecision(True, SessionReason.ACCEPTED)


def allow_additional_session(*, current_active_count: int, policy: SessionPolicy) -> bool:
    """Product MUST atomically enforce user session count before issuance."""
    _bounded_int(current_active_count, "active session count", 0, 1000000)
    return current_active_count < policy.max_concurrent_sessions
