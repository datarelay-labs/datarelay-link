"""Offline, product-neutral on-prem connectivity and clock/certificate health.

All evidence MUST come from a product-owned authoritative diagnostic runner.
This module performs no DNS lookup, socket connection, file access, NTP change,
proxy mutation, certificate access or privileged OS/system operation.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


def _nonnegative(value: int, name: str, maximum: int = 2**63 - 1) -> None:
    if type(value) is not int or not 0 <= value <= maximum:
        raise ValueError("invalid " + name)


class Severity(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    UNKNOWN = "unknown"
    SKIPPED = "skipped"


class DiagnosticArea(str, Enum):
    DNS = "dns"
    NTP = "ntp"
    PROXY = "proxy"
    TRUSTED_CA = "trusted_ca"
    CERTIFICATE = "certificate"


class Reason(str, Enum):
    HEALTHY = "healthy"
    EVIDENCE_STALE = "evidence_stale"
    EVIDENCE_UNAVAILABLE = "evidence_unavailable"
    DNS_FAILURE = "dns_failure"
    TIME_NOT_SYNCHRONIZED = "time_not_synchronized"
    TIME_OFFSET_HIGH = "time_offset_high"
    TIME_OFFSET_WARNING = "time_offset_warning"
    PROXY_DISABLED = "proxy_disabled"
    PROXY_FAILURE = "proxy_failure"
    TRUSTED_CA_NOT_CONFIGURED = "trusted_ca_not_configured"
    TRUSTED_CA_FAILURE = "trusted_ca_failure"
    CERTIFICATE_MISSING = "certificate_missing"
    CERTIFICATE_EXPIRED = "certificate_expired"
    CERTIFICATE_EXPIRING = "certificate_expiring"


class Remediation(str, Enum):
    NONE = "none"
    COLLECT_DIAGNOSTICS = "collect_diagnostics"
    CHECK_DNS = "check_dns"
    RESTORE_NTP = "restore_ntp"
    VERIFY_PROXY = "verify_proxy"
    CHECK_ENTERPRISE_CA = "check_enterprise_ca"
    RENEW_CERTIFICATE = "renew_certificate"


@dataclass(frozen=True)
class DiagnosticPolicy:
    max_evidence_age_seconds: int = 300
    ntp_warn_offset_ms: int = 10_000
    ntp_fail_offset_ms: int = 30_000
    certificate_warn_before_seconds: int = 30 * 86400

    def __post_init__(self) -> None:
        _nonnegative(self.max_evidence_age_seconds, "max evidence age", 86400)
        if self.max_evidence_age_seconds < 30:
            raise ValueError("evidence age too short")
        _nonnegative(self.ntp_warn_offset_ms, "NTP warning offset", 3600_000)
        _nonnegative(self.ntp_fail_offset_ms, "NTP failure offset", 3600_000)
        if not 1000 <= self.ntp_warn_offset_ms < self.ntp_fail_offset_ms:
            raise ValueError("invalid NTP warning/failure thresholds")
        _nonnegative(self.certificate_warn_before_seconds, "certificate warning", 365 * 86400)


@dataclass(frozen=True)
class NetworkEvidence:
    """No hostnames, URLs, certificate bytes, email addresses or secrets."""
    collected_at: int
    dns_ok: bool | None = None
    ntp_synchronized: bool | None = None
    ntp_offset_ms: int | None = None  # May be positive or negative.
    proxy_enabled: bool = False
    proxy_reachable: bool | None = None
    trusted_ca_configured: bool = False
    trusted_ca_verified: bool | None = None
    certificate_not_after: int | None = None

    def __post_init__(self) -> None:
        _nonnegative(self.collected_at, "evidence timestamp")
        for field_name in (
            "dns_ok", "ntp_synchronized", "proxy_reachable",
            "trusted_ca_verified",
        ):
            value = getattr(self, field_name)
            if value is not None and type(value) is not bool:
                raise ValueError("invalid " + field_name)
        for field_name in ("proxy_enabled", "trusted_ca_configured"):
            if type(getattr(self, field_name)) is not bool:
                raise ValueError("invalid " + field_name)
        if self.ntp_offset_ms is not None and (
            type(self.ntp_offset_ms) is not int
            or not -86_400_000 <= self.ntp_offset_ms <= 86_400_000
        ):
            raise ValueError("invalid NTP offset")
        if self.certificate_not_after is not None:
            _nonnegative(self.certificate_not_after, "certificate expiry")
        if self.proxy_reachable is not None and not self.proxy_enabled:
            raise ValueError("disabled proxy cannot report a reachability result")
        if self.trusted_ca_verified is not None and not self.trusted_ca_configured:
            raise ValueError("unconfigured CA cannot report a trust result")


@dataclass(frozen=True)
class DiagnosticFinding:
    area: DiagnosticArea
    severity: Severity
    code: Reason
    remediation: Remediation
    checked_at: int


@dataclass(frozen=True)
class DiagnosticReport:
    status: Severity
    findings: tuple[DiagnosticFinding, ...]
    collected_at: int


def _finding(area: DiagnosticArea, severity: Severity, code: Reason, fix: Remediation, at: int) -> DiagnosticFinding:
    return DiagnosticFinding(area, severity, code, fix, at)


def diagnose_network(
    evidence: NetworkEvidence,
    *,
    now: int,
    policy: DiagnosticPolicy = DiagnosticPolicy(),
) -> DiagnosticReport:
    """Generate stable actionable result codes, never use probe exceptions/text.

    NTP health directly affects a six-digit 30s TOTP login, so a large server
    clock offset is FAIL, not a mere display timezone preference.
    """
    if not isinstance(evidence, NetworkEvidence) or not isinstance(policy, DiagnosticPolicy):
        raise ValueError("invalid network evidence or policy")
    _nonnegative(now, "diagnostic timestamp")
    timestamp = evidence.collected_at
    areas = tuple(DiagnosticArea)
    if timestamp > now + 30 or now - timestamp > policy.max_evidence_age_seconds:
        items = tuple(_finding(area, Severity.UNKNOWN, Reason.EVIDENCE_STALE,
            Remediation.COLLECT_DIAGNOSTICS, timestamp) for area in areas)
        return DiagnosticReport(Severity.UNKNOWN, items, timestamp)

    findings: list[DiagnosticFinding] = []

    if evidence.dns_ok is None:
        findings.append(_finding(DiagnosticArea.DNS, Severity.UNKNOWN, Reason.EVIDENCE_UNAVAILABLE,
            Remediation.COLLECT_DIAGNOSTICS, timestamp))
    elif evidence.dns_ok:
        findings.append(_finding(DiagnosticArea.DNS, Severity.PASS, Reason.HEALTHY, Remediation.NONE, timestamp))
    else:
        findings.append(_finding(DiagnosticArea.DNS, Severity.FAIL, Reason.DNS_FAILURE,
            Remediation.CHECK_DNS, timestamp))

    offset = evidence.ntp_offset_ms
    if evidence.ntp_synchronized is False:
        findings.append(_finding(DiagnosticArea.NTP, Severity.FAIL, Reason.TIME_NOT_SYNCHRONIZED,
            Remediation.RESTORE_NTP, timestamp))
    elif evidence.ntp_synchronized is None or offset is None:
        findings.append(_finding(DiagnosticArea.NTP, Severity.UNKNOWN, Reason.EVIDENCE_UNAVAILABLE,
            Remediation.COLLECT_DIAGNOSTICS, timestamp))
    elif abs(offset) >= policy.ntp_fail_offset_ms:
        findings.append(_finding(DiagnosticArea.NTP, Severity.FAIL, Reason.TIME_OFFSET_HIGH,
            Remediation.RESTORE_NTP, timestamp))
    elif abs(offset) >= policy.ntp_warn_offset_ms:
        findings.append(_finding(DiagnosticArea.NTP, Severity.WARN, Reason.TIME_OFFSET_WARNING,
            Remediation.RESTORE_NTP, timestamp))
    else:
        findings.append(_finding(DiagnosticArea.NTP, Severity.PASS, Reason.HEALTHY, Remediation.NONE, timestamp))

    if not evidence.proxy_enabled:
        findings.append(_finding(DiagnosticArea.PROXY, Severity.SKIPPED, Reason.PROXY_DISABLED,
            Remediation.NONE, timestamp))
    elif evidence.proxy_reachable is None:
        findings.append(_finding(DiagnosticArea.PROXY, Severity.UNKNOWN, Reason.EVIDENCE_UNAVAILABLE,
            Remediation.COLLECT_DIAGNOSTICS, timestamp))
    elif not evidence.proxy_reachable:
        findings.append(_finding(DiagnosticArea.PROXY, Severity.FAIL, Reason.PROXY_FAILURE,
            Remediation.VERIFY_PROXY, timestamp))
    else:
        findings.append(_finding(DiagnosticArea.PROXY, Severity.PASS, Reason.HEALTHY, Remediation.NONE, timestamp))

    if not evidence.trusted_ca_configured:
        findings.append(_finding(DiagnosticArea.TRUSTED_CA, Severity.SKIPPED,
            Reason.TRUSTED_CA_NOT_CONFIGURED, Remediation.NONE, timestamp))
    elif evidence.trusted_ca_verified is None:
        findings.append(_finding(DiagnosticArea.TRUSTED_CA, Severity.UNKNOWN,
            Reason.EVIDENCE_UNAVAILABLE, Remediation.COLLECT_DIAGNOSTICS, timestamp))
    elif not evidence.trusted_ca_verified:
        findings.append(_finding(DiagnosticArea.TRUSTED_CA, Severity.FAIL,
            Reason.TRUSTED_CA_FAILURE, Remediation.CHECK_ENTERPRISE_CA, timestamp))
    else:
        findings.append(_finding(DiagnosticArea.TRUSTED_CA, Severity.PASS, Reason.HEALTHY,
            Remediation.NONE, timestamp))

    expiry = evidence.certificate_not_after
    if expiry is None:
        findings.append(_finding(DiagnosticArea.CERTIFICATE, Severity.UNKNOWN,
            Reason.CERTIFICATE_MISSING, Remediation.COLLECT_DIAGNOSTICS, timestamp))
    elif expiry <= now:
        findings.append(_finding(DiagnosticArea.CERTIFICATE, Severity.FAIL,
            Reason.CERTIFICATE_EXPIRED, Remediation.RENEW_CERTIFICATE, timestamp))
    elif expiry - now <= policy.certificate_warn_before_seconds:
        findings.append(_finding(DiagnosticArea.CERTIFICATE, Severity.WARN,
            Reason.CERTIFICATE_EXPIRING, Remediation.RENEW_CERTIFICATE, timestamp))
    else:
        findings.append(_finding(DiagnosticArea.CERTIFICATE, Severity.PASS,
            Reason.HEALTHY, Remediation.NONE, timestamp))

    severities = [x.severity for x in findings]
    if Severity.FAIL in severities:
        overall = Severity.FAIL
    elif Severity.UNKNOWN in severities:
        overall = Severity.UNKNOWN
    elif Severity.WARN in severities:
        overall = Severity.WARN
    else:
        overall = Severity.PASS
    return DiagnosticReport(overall, tuple(findings), timestamp)
