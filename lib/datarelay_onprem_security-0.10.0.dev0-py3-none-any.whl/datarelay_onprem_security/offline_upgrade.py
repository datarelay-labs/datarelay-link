"""Product-neutral, no-I/O offline update / restore qualification.

All digests/signatures/compatibility facts MUST be independently established by
the product's trusted installer against actual bytes, pinned publisher trust
and product-owned host/schema state. This module never installs or rolls back.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
import hmac
import re
from typing import Iterable

_REF = re.compile(r"[a-z][a-z0-9_.-]{0,95}", re.ASCII)
_SHA256 = re.compile(r"[0-9a-f]{64}", re.ASCII)
_VERSION = re.compile(r"(0|[1-9][0-9]{0,7})\.(0|[1-9][0-9]{0,7})\.(0|[1-9][0-9]{0,7})", re.ASCII)


def _ref(value: str, field: str) -> None:
    if not isinstance(value, str) or _REF.fullmatch(value) is None:
        raise ValueError("invalid " + field)


def _sha256(value: str, field: str) -> None:
    if not isinstance(value, str) or _SHA256.fullmatch(value) is None:
        raise ValueError("invalid " + field)


def verify_stream_sha256(
    chunks: Iterable[bytes],
    *,
    expected_sha256: str,
    expected_bytes: int,
) -> bool:
    """Hash actual source-provided artifact bytes with exact-size verification.

    The caller streams read-only data (max 8 MiB per chunk) from its own
    trusted offline source. This function neither opens a file nor performs
    network I/O; valid SHA256 alone NEVER authenticates a publisher signature
    or authorizes an installation.
    """
    _sha256(expected_sha256, "expected artifact sha256")
    _int(expected_bytes, "expected artifact bytes", 1, 2**60)
    if chunks is None or isinstance(chunks, (bytes, bytearray, memoryview, str)):
        raise ValueError("artifact source must be a bytes chunk iterable")
    try:
        iterator = iter(chunks)
    except TypeError as exc:
        raise ValueError("artifact source is not iterable") from exc
    digest = hashlib.sha256()
    processed = 0
    for chunk in iterator:
        if type(chunk) is not bytes or not chunk or len(chunk) > 8 * 1024 * 1024:
            raise ValueError("invalid artifact bytes chunk")
        processed += len(chunk)
        if processed > expected_bytes:
            return False
        digest.update(chunk)
    return processed == expected_bytes and hmac.compare_digest(
        digest.hexdigest(), expected_sha256
    )


def _version(value: str) -> tuple[int, int, int]:
    if not isinstance(value, str):
        raise ValueError("invalid version")
    match = _VERSION.fullmatch(value)
    if match is None:
        raise ValueError("invalid version")
    return tuple(int(v) for v in match.groups())


def _int(value: int, field: str, low: int = 0, high: int = 2**63 - 1) -> None:
    if type(value) is not int or not low <= value <= high:
        raise ValueError("invalid " + field)


@dataclass(frozen=True)
class InstalledProduct:
    product_ref: str
    installed_version: str
    current_revision: str
    schema_revision: int

    def __post_init__(self) -> None:
        _ref(self.product_ref, "product")
        _version(self.installed_version)
        _ref(self.current_revision, "installed revision")
        _int(self.schema_revision, "schema revision", 0, 2**31 - 1)


class ArtifactKind(str, Enum):
    PRODUCT_RELEASE = "product_release"
    PLATFORM_OS_UPGRADE = "platform_os_upgrade"


@dataclass(frozen=True)
class OfflineArtifact:
    product_ref: str
    release_ref: str
    version: str
    kind: ArtifactKind
    artifact_sha256: str
    manifest_sha256: str
    artifact_bytes: int
    publisher_key_ref: str

    def __post_init__(self) -> None:
        for name in ("product_ref", "release_ref", "publisher_key_ref"):
            _ref(getattr(self, name), name)
        _version(self.version)
        if type(self.kind) is not ArtifactKind:
            raise ValueError("invalid artifact kind")
        _sha256(self.artifact_sha256, "artifact sha256")
        _sha256(self.manifest_sha256, "manifest sha256")
        _int(self.artifact_bytes, "artifact size", 1, 2**60)


@dataclass(frozen=True)
class ArtifactProof:
    """Verified **against bytes** by a trusted installer, not the browser."""
    expected_artifact_sha256: str
    expected_manifest_sha256: str
    verified_publisher_key_ref: str
    artifact_bytes_hashed: bool = False
    manifest_bytes_hashed: bool = False
    manifest_signature_verified: bool = False
    publisher_trust_verified: bool = False
    provenance_verified: bool = False

    def __post_init__(self) -> None:
        _sha256(self.expected_artifact_sha256, "expected artifact hash")
        _sha256(self.expected_manifest_sha256, "expected manifest hash")
        _ref(self.verified_publisher_key_ref, "verified publisher")
        for name in ("artifact_bytes_hashed", "manifest_bytes_hashed",
                     "manifest_signature_verified", "publisher_trust_verified",
                     "provenance_verified"):
            if type(getattr(self, name)) is not bool:
                raise ValueError("invalid artifact verification flag")


@dataclass(frozen=True)
class UpgradeEvidence:
    expected_live_revision: str
    product_installer_supported: bool = False
    actor_authorized: bool = False
    recent_mfa_verified: bool = False
    schema_compatible: bool = False
    schema_migration_tested: bool = False
    backup_restore_drill_verified: bool = False
    rollback_artifact_verified: bool = False
    offline_console_recovery: bool = False
    maintenance_window_authorized: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        _ref(self.expected_live_revision, "expected live revision")
        for name in (
            "product_installer_supported", "actor_authorized",
            "recent_mfa_verified", "schema_compatible",
            "schema_migration_tested", "backup_restore_drill_verified",
            "rollback_artifact_verified", "offline_console_recovery",
            "maintenance_window_authorized", "audit_ready",
        ):
            if type(getattr(self, name)) is not bool:
                raise ValueError("invalid upgrade readiness flag")


class UpgradeBlocker(str, Enum):
    WRONG_PRODUCT = "wrong_product"
    WRONG_KIND = "wrong_kind"
    NOT_NEWER = "not_newer"
    MAJOR_UPGRADE_UNTESTED = "major_upgrade_untested"
    ARTIFACT_HASH_MISMATCH = "artifact_hash_mismatch"
    MANIFEST_HASH_MISMATCH = "manifest_hash_mismatch"
    PUBLISHER_MISMATCH = "publisher_mismatch"
    ARTIFACT_INTEGRITY_MISSING = "artifact_integrity_missing"
    MANIFEST_INTEGRITY_MISSING = "manifest_integrity_missing"
    SIGNATURE_UNVERIFIED = "signature_unverified"
    PUBLISHER_UNTRUSTED = "publisher_untrusted"
    PROVENANCE_UNVERIFIED = "provenance_unverified"
    STALE_INSTALLATION = "stale_installation"
    INSTALLER_UNAVAILABLE = "installer_unavailable"
    PERMISSION_DENIED = "permission_denied"
    MFA_REQUIRED = "mfa_required"
    SCHEMA_UNVERIFIED = "schema_unverified"
    MIGRATION_UNTESTED = "migration_untested"
    BACKUP_UNVERIFIED = "backup_unverified"
    ROLLBACK_UNVERIFIED = "rollback_unverified"
    OFFLINE_RECOVERY_REQUIRED = "offline_recovery_required"
    MAINTENANCE_NOT_AUTHORIZED = "maintenance_not_authorized"
    AUDIT_UNAVAILABLE = "audit_unavailable"


@dataclass(frozen=True)
class UpgradePreview:
    product_ref: str
    installed_version: str
    target_version: str
    release_ref: str
    blockers: tuple[UpgradeBlocker, ...]
    may_submit_to_product_installer: bool
    product_apply_required: bool = True


def preview_offline_upgrade(
    installed: InstalledProduct,
    artifact: OfflineArtifact,
    proof: ArtifactProof,
    evidence: UpgradeEvidence,
) -> UpgradePreview:
    """Read-only, no install. A 'ready' preview is NEVER an upgrade authority."""
    if not isinstance(installed, InstalledProduct) or not isinstance(artifact, OfflineArtifact):
        raise ValueError("invalid installation/artifact")
    if not isinstance(proof, ArtifactProof) or not isinstance(evidence, UpgradeEvidence):
        raise ValueError("invalid proof/evidence")
    blockers: list[UpgradeBlocker] = []
    if installed.product_ref != artifact.product_ref:
        blockers.append(UpgradeBlocker.WRONG_PRODUCT)
    if artifact.kind is not ArtifactKind.PRODUCT_RELEASE:
        # OS upgrade is a distinct privileged/native host workflow.
        blockers.append(UpgradeBlocker.WRONG_KIND)
    from_ver, to_ver = _version(installed.installed_version), _version(artifact.version)
    if to_ver <= from_ver:
        blockers.append(UpgradeBlocker.NOT_NEWER)
    if to_ver[0] > from_ver[0] and not evidence.schema_migration_tested:
        blockers.append(UpgradeBlocker.MAJOR_UPGRADE_UNTESTED)
    if proof.expected_artifact_sha256 != artifact.artifact_sha256:
        blockers.append(UpgradeBlocker.ARTIFACT_HASH_MISMATCH)
    if proof.expected_manifest_sha256 != artifact.manifest_sha256:
        blockers.append(UpgradeBlocker.MANIFEST_HASH_MISMATCH)
    if proof.verified_publisher_key_ref != artifact.publisher_key_ref:
        blockers.append(UpgradeBlocker.PUBLISHER_MISMATCH)
    if not proof.artifact_bytes_hashed:
        blockers.append(UpgradeBlocker.ARTIFACT_INTEGRITY_MISSING)
    if not proof.manifest_bytes_hashed:
        blockers.append(UpgradeBlocker.MANIFEST_INTEGRITY_MISSING)
    if not proof.manifest_signature_verified:
        blockers.append(UpgradeBlocker.SIGNATURE_UNVERIFIED)
    if not proof.publisher_trust_verified:
        blockers.append(UpgradeBlocker.PUBLISHER_UNTRUSTED)
    if not proof.provenance_verified:
        blockers.append(UpgradeBlocker.PROVENANCE_UNVERIFIED)
    if installed.current_revision != evidence.expected_live_revision:
        blockers.append(UpgradeBlocker.STALE_INSTALLATION)
    if not evidence.product_installer_supported:
        blockers.append(UpgradeBlocker.INSTALLER_UNAVAILABLE)
    if not evidence.actor_authorized:
        blockers.append(UpgradeBlocker.PERMISSION_DENIED)
    if not evidence.recent_mfa_verified:
        blockers.append(UpgradeBlocker.MFA_REQUIRED)
    if not evidence.schema_compatible:
        blockers.append(UpgradeBlocker.SCHEMA_UNVERIFIED)
    if not evidence.schema_migration_tested:
        blockers.append(UpgradeBlocker.MIGRATION_UNTESTED)
    if not evidence.backup_restore_drill_verified:
        blockers.append(UpgradeBlocker.BACKUP_UNVERIFIED)
    if not evidence.rollback_artifact_verified:
        blockers.append(UpgradeBlocker.ROLLBACK_UNVERIFIED)
    if not evidence.offline_console_recovery:
        blockers.append(UpgradeBlocker.OFFLINE_RECOVERY_REQUIRED)
    if not evidence.maintenance_window_authorized:
        blockers.append(UpgradeBlocker.MAINTENANCE_NOT_AUTHORIZED)
    if not evidence.audit_ready:
        blockers.append(UpgradeBlocker.AUDIT_UNAVAILABLE)
    return UpgradePreview(
        product_ref=installed.product_ref,
        installed_version=installed.installed_version,
        target_version=artifact.version,
        release_ref=artifact.release_ref,
        blockers=tuple(blockers),
        may_submit_to_product_installer=not blockers,
    )


@dataclass(frozen=True)
class UpgradeRollbackEvidence:
    expected_live_revision: str
    actor_authorized: bool = False
    recent_mfa_verified: bool = False
    product_rollback_supported: bool = False
    previous_artifact_verified: bool = False
    schema_restore_verified: bool = False
    current_data_backup_verified: bool = False
    offline_console_recovery: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        _ref(self.expected_live_revision, "expected live revision")
        for name in (
            "actor_authorized", "recent_mfa_verified",
            "product_rollback_supported", "previous_artifact_verified",
            "schema_restore_verified", "current_data_backup_verified",
            "offline_console_recovery", "audit_ready",
        ):
            if type(getattr(self, name)) is not bool:
                raise ValueError("invalid rollback readiness flag")


class UpgradeRollbackBlocker(str, Enum):
    WRONG_PRODUCT = "wrong_product"
    NOT_OLDER_VERSION = "not_older_version"
    STALE_INSTALLATION = "stale_installation"
    PERMISSION_DENIED = "permission_denied"
    MFA_REQUIRED = "mfa_required"
    ROLLBACK_UNAVAILABLE = "rollback_unavailable"
    OLD_ARTIFACT_UNVERIFIED = "old_artifact_unverified"
    SCHEMA_ROLLBACK_UNVERIFIED = "schema_rollback_unverified"
    CURRENT_DATA_BACKUP_MISSING = "current_data_backup_missing"
    OFFLINE_RECOVERY_REQUIRED = "offline_recovery_required"
    AUDIT_UNAVAILABLE = "audit_unavailable"


@dataclass(frozen=True)
class UpgradeRollbackPreview:
    product_ref: str
    installed_version: str
    target_version: str
    blockers: tuple[UpgradeRollbackBlocker, ...]
    may_submit_to_product_rollback: bool
    product_apply_required: bool = True


def preview_offline_rollback(
    installed: InstalledProduct,
    target: OfflineArtifact,
    evidence: UpgradeRollbackEvidence,
) -> UpgradeRollbackPreview:
    """Advisory; product must revalidate offline artifact byte/signature proof."""
    if not isinstance(installed, InstalledProduct) or not isinstance(target, OfflineArtifact):
        raise ValueError("invalid installation/rollback artifact")
    if not isinstance(evidence, UpgradeRollbackEvidence):
        raise ValueError("invalid rollback evidence")
    blockers: list[UpgradeRollbackBlocker] = []
    if installed.product_ref != target.product_ref or target.kind is not ArtifactKind.PRODUCT_RELEASE:
        blockers.append(UpgradeRollbackBlocker.WRONG_PRODUCT)
    if _version(target.version) >= _version(installed.installed_version):
        blockers.append(UpgradeRollbackBlocker.NOT_OLDER_VERSION)
    if evidence.expected_live_revision != installed.current_revision:
        blockers.append(UpgradeRollbackBlocker.STALE_INSTALLATION)
    if not evidence.actor_authorized:
        blockers.append(UpgradeRollbackBlocker.PERMISSION_DENIED)
    if not evidence.recent_mfa_verified:
        blockers.append(UpgradeRollbackBlocker.MFA_REQUIRED)
    if not evidence.product_rollback_supported:
        blockers.append(UpgradeRollbackBlocker.ROLLBACK_UNAVAILABLE)
    if not evidence.previous_artifact_verified:
        blockers.append(UpgradeRollbackBlocker.OLD_ARTIFACT_UNVERIFIED)
    if not evidence.schema_restore_verified:
        blockers.append(UpgradeRollbackBlocker.SCHEMA_ROLLBACK_UNVERIFIED)
    if not evidence.current_data_backup_verified:
        blockers.append(UpgradeRollbackBlocker.CURRENT_DATA_BACKUP_MISSING)
    if not evidence.offline_console_recovery:
        blockers.append(UpgradeRollbackBlocker.OFFLINE_RECOVERY_REQUIRED)
    if not evidence.audit_ready:
        blockers.append(UpgradeRollbackBlocker.AUDIT_UNAVAILABLE)
    return UpgradeRollbackPreview(
        product_ref=installed.product_ref,
        installed_version=installed.installed_version,
        target_version=target.version,
        blockers=tuple(blockers),
        may_submit_to_product_rollback=not blockers,
    )
