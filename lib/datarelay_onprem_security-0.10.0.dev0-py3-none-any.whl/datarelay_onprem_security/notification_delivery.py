"""Pure notification routing state, retry and test-send admission contract.

Product adapters own SMTP/Webhook credentials, message bodies, recipient
resolution, network requests, durable queues and real acknowledgement.
No outbound network/file operation occurs in this module.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
import re

_REF = re.compile(r"[a-z][a-z0-9_.-]{0,95}", re.ASCII)


def _ref(value: str, label: str) -> None:
    if not isinstance(value, str) or _REF.fullmatch(value) is None:
        raise ValueError("invalid " + label)


def _int(value: int, label: str, minimum: int = 0, maximum: int = 2**63 - 1) -> None:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError("invalid " + label)


class NotificationKind(str, Enum):
    SMTP = "smtp"
    WEBHOOK = "webhook"


@dataclass(frozen=True)
class NotificationDestination:
    """Opaque backend reference only — NEVER an SMTP password, URL or host."""
    reference: str
    kind: NotificationKind
    revision: str
    enabled: bool = False
    credential_reference: str | None = None

    def __post_init__(self) -> None:
        _ref(self.reference, "destination reference")
        _ref(self.revision, "destination revision")
        if type(self.kind) is not NotificationKind:
            raise ValueError("invalid notification kind")
        if type(self.enabled) is not bool:
            raise ValueError("invalid notification enabled state")
        if self.credential_reference is not None:
            _ref(self.credential_reference, "credential reference")


@dataclass(frozen=True)
class NotificationRetryPolicy:
    max_attempts: int = 5
    initial_delay_seconds: int = 30
    max_delay_seconds: int = 3600

    def __post_init__(self) -> None:
        _int(self.max_attempts, "max attempts", 1, 20)
        _int(self.initial_delay_seconds, "initial retry delay", 1, 3600)
        _int(self.max_delay_seconds, "max retry delay", self.initial_delay_seconds, 86400)


class NotificationState(str, Enum):
    QUEUED = "queued"
    RETRY_PENDING = "retry_pending"
    ACCEPTED = "accepted"
    DEAD_LETTER = "dead_letter"


@dataclass(frozen=True)
class NotificationJob:
    """Durable product queue snapshot without a message or recipient payload."""
    job_ref: str
    event_ref: str
    destination_ref: str
    destination_revision: str
    state: NotificationState = NotificationState.QUEUED
    attempts: int = 0
    created_at: int = 0
    last_attempt_at: int | None = None
    retry_at: int | None = None

    def __post_init__(self) -> None:
        for k in ("job_ref", "event_ref", "destination_ref", "destination_revision"):
            _ref(getattr(self, k), k)
        if type(self.state) is not NotificationState:
            raise ValueError("invalid notification state")
        _int(self.attempts, "attempts", 0, 20)
        _int(self.created_at, "created_at")
        if self.last_attempt_at is not None:
            _int(self.last_attempt_at, "last_attempt_at")
        if self.retry_at is not None:
            _int(self.retry_at, "retry_at")
        if self.attempts and self.last_attempt_at is None:
            raise ValueError("attempted notification missing time")
        if self.last_attempt_at is not None and self.last_attempt_at < self.created_at:
            raise ValueError("notification attempt predates queue entry")
        if self.state is NotificationState.QUEUED and (
            self.attempts != 0 or self.retry_at is not None
        ):
            raise ValueError("invalid queued notification")
        if self.state is NotificationState.RETRY_PENDING and (
            self.attempts == 0 or self.retry_at is None
            or self.retry_at <= self.last_attempt_at
        ):
            raise ValueError("invalid retry_pending notification")
        if self.state in (NotificationState.ACCEPTED, NotificationState.DEAD_LETTER) and self.retry_at is not None:
            raise ValueError("terminal notification cannot have retry time")


class AttemptOutcome(str, Enum):
    ACCEPTED = "accepted"
    RETRYABLE_FAILURE = "retryable_failure"
    PERMANENT_FAILURE = "permanent_failure"


class NotificationError(str, Enum):
    STALE_ATTEMPT = "stale_attempt"
    NOT_DUE = "not_due"
    TERMINAL = "terminal"
    WRONG_DESTINATION = "wrong_destination"
    STALE_DESTINATION = "stale_destination"
    DESTINATION_DISABLED = "destination_disabled"


@dataclass(frozen=True)
class AttemptDecision:
    next_job: NotificationJob | None
    error: NotificationError | None


def admit_delivery_attempt(
    job: NotificationJob,
    destination: NotificationDestination,
    *,
    expected_attempts: int,
    now: int,
    policy: NotificationRetryPolicy = NotificationRetryPolicy(),
) -> NotificationError | None:
    """Check the queue and destination BEFORE performing an external send.

    The product must also verify the same version/counter under its durable
    queue lock so that queued messages cannot bypass a newly disabled or
    replaced SMTP/Webhook endpoint.
    """
    if not isinstance(job, NotificationJob) or not isinstance(destination, NotificationDestination):
        raise ValueError("invalid notification resource")
    if not isinstance(policy, NotificationRetryPolicy):
        raise ValueError("invalid notification retry policy")
    _int(now, "attempt timestamp")
    _int(expected_attempts, "expected attempt count", 0, 20)
    if destination.reference != job.destination_ref:
        return NotificationError.WRONG_DESTINATION
    if destination.revision != job.destination_revision:
        return NotificationError.STALE_DESTINATION
    if not destination.enabled:
        return NotificationError.DESTINATION_DISABLED
    if job.state in (NotificationState.ACCEPTED, NotificationState.DEAD_LETTER):
        return NotificationError.TERMINAL
    if job.attempts >= policy.max_attempts:
        return NotificationError.TERMINAL
    if job.attempts != expected_attempts:
        return NotificationError.STALE_ATTEMPT
    if now < job.created_at or (job.last_attempt_at is not None and now < job.last_attempt_at):
        return NotificationError.NOT_DUE
    if job.retry_at is not None and now < job.retry_at:
        return NotificationError.NOT_DUE
    return None


def record_delivery_attempt(
    job: NotificationJob,
    destination: NotificationDestination,
    *,
    outcome: AttemptOutcome,
    expected_attempts: int,
    now: int,
    policy: NotificationRetryPolicy = NotificationRetryPolicy(),
) -> AttemptDecision:
    """Pure proposal requiring atomic compare-and-swap in product-owned DB.

    A caller must persist new state and a stable idempotency key before any
    real send, and check the current destination revision/enablement again.
    A local proposal is NOT a delivery receipt from the SMTP/Webhook service.
    """
    if type(outcome) is not AttemptOutcome:
        raise ValueError("invalid notification attempt outcome")
    blocked = admit_delivery_attempt(
        job, destination, expected_attempts=expected_attempts,
        now=now, policy=policy,
    )
    if blocked is not None:
        return AttemptDecision(None, blocked)

    attempts = job.attempts + 1
    if outcome is AttemptOutcome.ACCEPTED:
        return AttemptDecision(replace(job,
            state=NotificationState.ACCEPTED, attempts=attempts,
            last_attempt_at=now, retry_at=None), None)
    if outcome is AttemptOutcome.PERMANENT_FAILURE or attempts >= policy.max_attempts:
        return AttemptDecision(replace(job,
            state=NotificationState.DEAD_LETTER, attempts=attempts,
            last_attempt_at=now, retry_at=None), None)
    delay = min(policy.initial_delay_seconds * 2 ** (attempts - 1), policy.max_delay_seconds)
    return AttemptDecision(replace(job,
        state=NotificationState.RETRY_PENDING, attempts=attempts,
        last_attempt_at=now, retry_at=now + delay), None)


@dataclass(frozen=True)
class TestSendEvidence:
    """Product-backed facts only; never an API authorization token."""
    expected_revision: str
    actor_can_test: bool = False
    recent_mfa_verified: bool = False
    product_sender_ready: bool = False
    destination_validated: bool = False
    credential_ready: bool = False
    secure_transport_verified: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        _ref(self.expected_revision, "expected revision")
        for key in (
            "actor_can_test", "recent_mfa_verified", "product_sender_ready",
            "destination_validated", "credential_ready", "secure_transport_verified",
            "audit_ready",
        ):
            if type(getattr(self, key)) is not bool:
                raise ValueError("invalid notification evidence")


class TestSendBlocker(str, Enum):
    DESTINATION_DISABLED = "destination_disabled"
    STALE_DESTINATION = "stale_destination"
    PERMISSION_DENIED = "permission_denied"
    MFA_REQUIRED = "mfa_required"
    SENDER_UNAVAILABLE = "sender_unavailable"
    DESTINATION_UNVERIFIED = "destination_unverified"
    CREDENTIAL_UNAVAILABLE = "credential_unavailable"
    TLS_UNVERIFIED = "tls_unverified"
    AUDIT_UNAVAILABLE = "audit_unavailable"


@dataclass(frozen=True)
class TestSendPreview:
    destination_ref: str
    blockers: tuple[TestSendBlocker, ...]
    may_submit_to_product_sender: bool
    product_send_required: bool = True


def preview_test_send(
    destination: NotificationDestination,
    evidence: TestSendEvidence,
) -> TestSendPreview:
    """Never sends mail/webhook or authorizes a product permission boundary."""
    blockers: list[TestSendBlocker] = []
    if not destination.enabled:
        blockers.append(TestSendBlocker.DESTINATION_DISABLED)
    if evidence.expected_revision != destination.revision:
        blockers.append(TestSendBlocker.STALE_DESTINATION)
    if not evidence.actor_can_test:
        blockers.append(TestSendBlocker.PERMISSION_DENIED)
    if not evidence.recent_mfa_verified:
        blockers.append(TestSendBlocker.MFA_REQUIRED)
    if not evidence.product_sender_ready:
        blockers.append(TestSendBlocker.SENDER_UNAVAILABLE)
    if not evidence.destination_validated:
        blockers.append(TestSendBlocker.DESTINATION_UNVERIFIED)
    if destination.credential_reference is not None and not evidence.credential_ready:
        blockers.append(TestSendBlocker.CREDENTIAL_UNAVAILABLE)
    if not evidence.secure_transport_verified:
        blockers.append(TestSendBlocker.TLS_UNVERIFIED)
    if not evidence.audit_ready:
        blockers.append(TestSendBlocker.AUDIT_UNAVAILABLE)
    return TestSendPreview(destination.reference, tuple(blockers), not blockers)
