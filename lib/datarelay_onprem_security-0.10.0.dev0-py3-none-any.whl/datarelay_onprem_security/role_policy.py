"""Product-neutral role/capability projection and read-only privilege-change review.

A product MUST derive these facts from its current authoritative server
session, role store and capability registry. UI-visible decisions are NEVER
substitutes for server-side authorization or a product database transaction.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import re

_ID = re.compile(r"[a-z][a-z0-9_.-]{0,95}", re.ASCII)


def _id(value: str, name: str) -> str:
    if not isinstance(value, str) or _ID.fullmatch(value) is None:
        raise ValueError("invalid " + name)
    return value


def _ids(value: frozenset[str], name: str) -> frozenset[str]:
    if not isinstance(value, frozenset):
        raise ValueError("invalid " + name)
    for item in value:
        _id(item, name)
    if len(value) > 1024:
        raise ValueError("too many " + name)
    return value


class Availability(str, Enum):
    SUPPORTED = "supported"
    READ_ONLY = "read_only"
    UNAVAILABLE = "unavailable"


class Access(str, Enum):
    MANAGE = "manage"
    VIEW = "view"
    NONE = "none"


@dataclass(frozen=True)
class CapabilityProjection:
    """Exactly what the product backend implements AND the actor may access."""
    capability_id: str
    availability: Availability
    actor_access: Access

    def __post_init__(self) -> None:
        _id(self.capability_id, "capability id")
        if type(self.availability) is not Availability:
            raise ValueError("invalid availability")
        if type(self.actor_access) is not Access:
            raise ValueError("invalid actor access")


def effective_access(capability: CapabilityProjection) -> Access:
    """Safe presentation intersection; product API must check rights again."""
    if not isinstance(capability, CapabilityProjection):
        raise ValueError("invalid capability")
    if capability.availability is Availability.UNAVAILABLE or capability.actor_access is Access.NONE:
        return Access.NONE
    if capability.availability is Availability.READ_ONLY or capability.actor_access is Access.VIEW:
        return Access.VIEW
    return Access.MANAGE


@dataclass(frozen=True)
class RoleCapabilities:
    """Opaque, product-defined role/capabilities; no central role dictionary."""
    role_ref: str
    revision: str
    capabilities: frozenset[str]

    def __post_init__(self) -> None:
        _id(self.role_ref, "role reference")
        _id(self.revision, "role revision")
        _ids(self.capabilities, "role capabilities")


@dataclass(frozen=True)
class RoleChangeEvidence:
    """Product-derived transaction facts only; never caller-submitted auth."""
    actor_ref: str
    subject_ref: str
    expected_current_revision: str
    actor_can_manage_roles: bool = False
    recent_mfa_verified: bool = False
    product_role_write_supported: bool = False
    audit_ready: bool = False
    rollback_ready: bool = False
    last_admin_preserved: bool = False
    external_approval_granted: bool = False

    def __post_init__(self) -> None:
        for k in ("actor_ref", "subject_ref", "expected_current_revision"):
            _id(getattr(self, k), k)
        for k in (
            "actor_can_manage_roles", "recent_mfa_verified", "product_role_write_supported",
            "audit_ready", "rollback_ready", "last_admin_preserved", "external_approval_granted",
        ):
            if type(getattr(self, k)) is not bool:
                raise ValueError("invalid role evidence")


class RoleChangeBlocker(str, Enum):
    NO_PRODUCT_BACKEND = "no_product_backend"
    PERMISSION_DENIED = "permission_denied"
    MFA_REQUIRED = "mfa_required"
    STALE_ROLE = "stale_role"
    UNKNOWN_CAPABILITY = "unknown_capability"
    LAST_ADMIN_LOCKOUT = "last_admin_lockout"
    SELF_ESCALATION = "self_escalation"
    ESCALATION_APPROVAL_REQUIRED = "escalation_approval_required"
    AUDIT_UNAVAILABLE = "audit_unavailable"
    ROLLBACK_UNAVAILABLE = "rollback_unavailable"


@dataclass(frozen=True)
class RoleChangePreview:
    """Advisory changeset; product must revalidate all facts under DB lock."""
    from_role_ref: str
    to_role_ref: str
    gained: tuple[str, ...]
    lost: tuple[str, ...]
    blockers: tuple[RoleChangeBlocker, ...]
    may_submit_to_product_authority: bool
    product_write_required: bool = True


def preview_role_change(
    current: RoleCapabilities,
    proposed: RoleCapabilities,
    *,
    registry_capabilities: frozenset[str],
    evidence: RoleChangeEvidence,
) -> RoleChangePreview:
    """Safely preview privilege changes with explicit bounded registry.

    Effective permissions must come from authoritative product Core/DB.
    Even an unblocked result is not an authorization grant or a signed token.
    """
    if not isinstance(current, RoleCapabilities) or not isinstance(proposed, RoleCapabilities):
        raise ValueError("invalid role binding")
    _ids(registry_capabilities, "registry capabilities")
    gained = tuple(sorted(proposed.capabilities - current.capabilities))
    lost = tuple(sorted(current.capabilities - proposed.capabilities))
    blockers: list[RoleChangeBlocker] = []
    if not evidence.product_role_write_supported:
        blockers.append(RoleChangeBlocker.NO_PRODUCT_BACKEND)
    if not evidence.actor_can_manage_roles:
        blockers.append(RoleChangeBlocker.PERMISSION_DENIED)
    if not evidence.recent_mfa_verified:
        blockers.append(RoleChangeBlocker.MFA_REQUIRED)
    if evidence.expected_current_revision != current.revision:
        blockers.append(RoleChangeBlocker.STALE_ROLE)
    if not proposed.capabilities.issubset(registry_capabilities):
        blockers.append(RoleChangeBlocker.UNKNOWN_CAPABILITY)
    if not evidence.last_admin_preserved:
        blockers.append(RoleChangeBlocker.LAST_ADMIN_LOCKOUT)
    if gained and evidence.actor_ref == evidence.subject_ref:
        blockers.append(RoleChangeBlocker.SELF_ESCALATION)
    if gained and not evidence.external_approval_granted:
        blockers.append(RoleChangeBlocker.ESCALATION_APPROVAL_REQUIRED)
    if not evidence.audit_ready:
        blockers.append(RoleChangeBlocker.AUDIT_UNAVAILABLE)
    if not evidence.rollback_ready:
        blockers.append(RoleChangeBlocker.ROLLBACK_UNAVAILABLE)
    return RoleChangePreview(
        from_role_ref=current.role_ref,
        to_role_ref=proposed.role_ref,
        gained=gained,
        lost=lost,
        blockers=tuple(blockers),
        may_submit_to_product_authority=not blockers,
    )
