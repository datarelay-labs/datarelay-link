"""Shared management ingress allowlist engine; never changes host firewall or sshd.

"ssh" is the PRODUCT HOST SSH endpoint. "web" includes Web UI AND every
management API endpoint. Link's remote/proxied-service ACL is a separate policy.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import ipaddress
import time
from typing import Literal

Target = Literal["ssh", "web"]


def _ip(raw: object):
    try:
        addr = ipaddress.ip_address(raw)
    except (ValueError, TypeError):
        return None
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        return addr.ipv4_mapped
    return addr


def canonical_network(raw: str) -> str:
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError("missing source CIDR")
    try:
        net = ipaddress.ip_network(raw.strip(), strict=False)
    except ValueError as exc:
        raise ValueError("invalid IP/CIDR") from exc
    if net.prefixlen == 0:
        raise ValueError("unrestricted /0 is not a useful allowlist")
    if isinstance(net, ipaddress.IPv6Network):
        mapped_range = ipaddress.IPv6Network("::ffff:0:0/96")
        if net.subnet_of(mapped_range):
            # Canonicalize IPv4-mapped IPv6 to the *same* policy identity as
            # ordinary IPv4, so either socket-address representation matches.
            # /96 is equivalent to IPv4 /0 and is never an allowlist.
            if net.prefixlen == 96:
                raise ValueError("unrestricted IPv4-mapped /0 is not an allowlist")
            mapped = net.network_address.ipv4_mapped
            if mapped is None:
                raise ValueError("invalid IPv4-mapped network")
            return str(ipaddress.IPv4Network((int(mapped), net.prefixlen - 96)))
        if mapped_range.subnet_of(net):
            # A broad IPv6 range including *all* IPv4-mapped sources has
            # ambiguous cross-family semantics: reject rather than weaken
            # the IPv4 allowlist.
            raise ValueError("IPv6 range includes all IPv4-mapped addresses")
    return str(net)


@dataclass(frozen=True)
class AllowEntry:
    cidr: str
    name: str = ""
    expires_at: int | None = None   # UTC epoch seconds

    def __post_init__(self):
        object.__setattr__(self, "cidr", canonical_network(self.cidr))
        if not isinstance(self.name, str) or len(self.name) > 64:
            raise ValueError("invalid source name")
        if self.expires_at is not None and (
            type(self.expires_at) is not int or self.expires_at <= 0
        ):
            raise ValueError("invalid expiry")

    def is_active(self, at: int) -> bool:
        return self.expires_at is None or at < self.expires_at

    def contains(self, source, at: int) -> bool:
        return self.is_active(at) and source in ipaddress.ip_network(self.cidr)


@dataclass(frozen=True)
class SurfacePolicy:
    enabled: bool = False  # Disabled by default on a fresh on-prem install.
    sources: tuple[AllowEntry, ...] = ()
    revision: str = ""

    def __post_init__(self):
        if type(self.enabled) is not bool:
            raise ValueError("enabled must be boolean")
        if not isinstance(self.sources, tuple) or any(
            not isinstance(s, AllowEntry) for s in self.sources
        ):
            raise ValueError("sources must be a tuple of AllowEntry")
        if len(set(entry.cidr for entry in self.sources)) != len(self.sources):
            raise ValueError("duplicate CIDR")
        if self.enabled and not self.sources:
            raise ValueError("empty enabled allowlist")
        if not isinstance(self.revision, str) or len(self.revision) > 128:
            raise ValueError("invalid revision")


@dataclass(frozen=True)
class ManagementPolicy:
    ssh: SurfacePolicy = field(default_factory=SurfacePolicy)
    web: SurfacePolicy = field(default_factory=SurfacePolicy)


class Reason(str, Enum):
    ALLOW_DISABLED = "ALLOW_DISABLED"
    ALLOW_CIDR = "ALLOW_CIDR"
    DENY_POLICY_UNAVAILABLE = "DENY_POLICY_UNAVAILABLE"
    DENY_UNKNOWN_SOURCE = "DENY_UNKNOWN_SOURCE"
    DENY_NO_MATCH = "DENY_NO_MATCH"
    DENY_EXPIRED = "DENY_EXPIRED"


@dataclass(frozen=True)
class Decision:
    allowed: bool
    reason: Reason
    source: str | None = None
    matched_cidr: str | None = None


def authorize(policy: SurfacePolicy | None, source_ip: str | None, *, now: int | None = None) -> Decision:
    if policy is None:
        return Decision(False, Reason.DENY_POLICY_UNAVAILABLE)
    if not policy.enabled:
        return Decision(True, Reason.ALLOW_DISABLED)
    ip = _ip(source_ip)
    if ip is None:
        return Decision(False, Reason.DENY_UNKNOWN_SOURCE)
    at = int(time.time()) if now is None else int(now)
    for entry in policy.sources:
        if entry.contains(ip, at):
            return Decision(True, Reason.ALLOW_CIDR, str(ip), entry.cidr)
    cause = Reason.DENY_EXPIRED if all(not e.is_active(at) for e in policy.sources) else Reason.DENY_NO_MATCH
    return Decision(False, cause, str(ip))


def resolve_web_source(
    direct_peer: str | None,
    x_forwarded_for: str | None = None,
    *,
    trusted_proxy_cidrs: tuple[str, ...] = (),
) -> str | None:
    """Use XFF only when immediate peer is explicitly trusted; never trust /0.

    Reverse proxies MUST replace/append incoming spoofed XFF correctly.
    All malformed chains fail closed. HTTP Forwarded is intentionally ignored.
    """
    peer = _ip(direct_peer)
    if peer is None:
        return None
    trusted = tuple(ipaddress.ip_network(canonical_network(c)) for c in trusted_proxy_cidrs)
    if not any(peer in net for net in trusted):
        return str(peer)
    if not x_forwarded_for:
        # A known proxy's socket IP is NOT the end-user source. Otherwise
        # an allowed loopback/proxy address would permit every client when
        # the proxy omits the identifying header.
        return None
    parts = [part.strip() for part in x_forwarded_for.split(",")]
    if not 1 <= len(parts) <= 16:
        return None
    hops = [_ip(p) for p in parts]
    if any(hop is None for hop in hops):
        return None
    for hop in reversed(hops):
        if not any(hop in net for net in trusted):
            return str(hop)
    return None  # Source unknown when all claimed hops are proxies.


def authorize_management(
    config: ManagementPolicy | None,
    target: Target,
    *,
    direct_peer: str | None,
    x_forwarded_for: str | None = None,
    trusted_proxy_cidrs: tuple[str, ...] = (),
    now: int | None = None,
) -> Decision:
    if config is None:
        return Decision(False, Reason.DENY_POLICY_UNAVAILABLE)
    if target == "ssh":
        return authorize(config.ssh, direct_peer, now=now)
    if target == "web":
        ip = resolve_web_source(direct_peer, x_forwarded_for, trusted_proxy_cidrs=trusted_proxy_cidrs)
        return authorize(config.web, ip, now=now)
    raise ValueError("unknown management ingress target")


@dataclass(frozen=True)
class AccessChangePreview:
    safe: bool
    blockers: tuple[str, ...]
    web_decision: Decision
    ssh_decision: Decision
    rollback_seconds: int


def preview_change(
    candidate: ManagementPolicy,
    *,
    current_web_source: str | None,
    current_ssh_source: str | None,
    emergency_console_confirmed: bool,
    ssh_enforcement_supported: bool,
    rollback_seconds: int = 180,
    now: int | None = None,
) -> AccessChangePreview:
    """Read-only advisory gate, NOT authorization to modify host permissions.

    The real host adapter must install a durable rollback timer, perform
    atomic revision-checked apply, and read back effective SSH/Web filters.
    """
    errors = []
    if not 60 <= rollback_seconds <= 3600:
        errors.append("INVALID_ROLLBACK_WINDOW")
    if not emergency_console_confirmed:
        errors.append("OFFLINE_RECOVERY_REQUIRED")
    if candidate.ssh.enabled and not ssh_enforcement_supported:
        errors.append("SSH_ENFORCEMENT_UNAVAILABLE")
    web = authorize(candidate.web, current_web_source, now=now)
    ssh = authorize(candidate.ssh, current_ssh_source, now=now)
    if candidate.web.enabled and not web.allowed:
        errors.append("WEB_SELF_LOCKOUT")
    if candidate.ssh.enabled and not ssh.allowed:
        errors.append("SSH_SELF_LOCKOUT")
    return AccessChangePreview(not errors, tuple(errors), web, ssh, rollback_seconds)
