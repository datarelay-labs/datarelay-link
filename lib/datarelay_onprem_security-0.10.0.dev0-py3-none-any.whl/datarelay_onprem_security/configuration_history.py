"""Safe, product-neutral logical configuration revisions and rollback previews.

Only pre-sanitized, allowlisted non-secret scalar settings may enter this
module. Never reads files/DBs, authorizes a user, or executes rollback.
Products retain backup, actual config state and permission/host authority.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
import json
import re

_ID = re.compile(r"[a-z][a-z0-9_.-]{0,95}", re.ASCII)
_PATH = re.compile(r"[a-z][a-z0-9_.-]{0,127}", re.ASCII)
_VALUE = re.compile(r"[A-Za-z0-9_.@:/+-]{1,80}", re.ASCII)
_REDACTED_WORDS = frozenset((
    "password", "passwd", "secret", "token", "apikey",
    "api_key", "credential", "private", "master_key",
    "recovery", "key_material",
))


def _ref(value: str, name: str) -> str:
    if not isinstance(value, str) or _ID.fullmatch(value) is None:
        raise ValueError("invalid " + name)
    return value


def _path(value: str) -> str:
    if not isinstance(value, str) or _PATH.fullmatch(value) is None:
        raise ValueError("invalid configuration path")
    segments = tuple(part for part in value.split(".") if part)
    if any(any(word in part for word in _REDACTED_WORDS) for part in segments):
        raise ValueError("sensitive configuration path is not diffable")
    return value


def _scalar(value: object) -> str:
    if type(value) is bool:
        return "true" if value else "false"
    if type(value) is int and 0 <= value <= 2**53 - 1:
        return str(value)
    if type(value) is str and _VALUE.fullmatch(value) is not None:
        return value
    raise ValueError("configuration value is not a safe scalar")


@dataclass(frozen=True)
class ConfigField:
    """A value classified non-secret by the product's authoritative adapter."""
    path: str
    value: str | int | bool

    def __post_init__(self) -> None:
        _path(self.path)
        _scalar(self.value)


@dataclass(frozen=True)
class ConfigRevision:
    product_ref: str
    revision_ref: str
    actor_ref: str
    created_at: int
    fields: tuple[ConfigField, ...]

    def __post_init__(self) -> None:
        for name in ("product_ref", "revision_ref", "actor_ref"):
            _ref(getattr(self, name), name)
        if type(self.created_at) is not int or not 0 <= self.created_at <= 2**63 - 1:
            raise ValueError("invalid configuration timestamp")
        if not isinstance(self.fields, tuple) or len(self.fields) > 512:
            raise ValueError("invalid configuration fields")
        keys: set[str] = set()
        for field in self.fields:
            if not isinstance(field, ConfigField):
                raise ValueError("invalid configuration field")
            if field.path in keys:
                raise ValueError("duplicate configuration path")
            keys.add(field.path)


@dataclass(frozen=True)
class ConfigChange:
    path: str
    before: str | None
    after: str | None


@dataclass(frozen=True)
class ConfigDiff:
    product_ref: str
    from_revision: str
    to_revision: str
    changes: tuple[ConfigChange, ...]
    from_fingerprint: str
    to_fingerprint: str


def _registry(registry: frozenset[str], name: str) -> frozenset[str]:
    if not isinstance(registry, frozenset) or len(registry) > 512:
        raise ValueError("invalid " + name)
    for item in registry:
        _path(item)
    return registry


def _map(revision: ConfigRevision, allowed: frozenset[str]) -> dict[str, str]:
    out = {}
    for f in revision.fields:
        if f.path not in allowed:
            raise ValueError("configuration field is not allowlisted")
        out[f.path] = _scalar(f.value)
    return out


def _fingerprint(revision: ConfigRevision, fields: dict[str, str]) -> str:
    # No secret may be fed to this function. Canonical ordering gives a
    # deterministic receipt independent of product DB row iteration order.
    body = json.dumps({
        "product": revision.product_ref,
        "revision": revision.revision_ref,
        "fields": fields,
    }, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("ascii")
    return hashlib.sha256(body).hexdigest()


def diff_configurations(
    previous: ConfigRevision,
    current: ConfigRevision,
    *,
    allowlisted_paths: frozenset[str],
) -> ConfigDiff:
    if not isinstance(previous, ConfigRevision) or not isinstance(current, ConfigRevision):
        raise ValueError("invalid configuration revision")
    if previous.product_ref != current.product_ref:
        raise ValueError("cross-product configuration diff is not permitted")
    allowed = _registry(allowlisted_paths, "configuration allowlist")
    a = _map(previous, allowed)
    b = _map(current, allowed)
    if previous.revision_ref == current.revision_ref and a != b:
        raise ValueError("conflicting contents under one configuration revision")
    all_keys = sorted(set(a) | set(b))
    changes = tuple(
        ConfigChange(key, a.get(key), b.get(key))
        for key in all_keys if a.get(key) != b.get(key)
    )
    return ConfigDiff(
        product_ref=previous.product_ref,
        from_revision=previous.revision_ref,
        to_revision=current.revision_ref,
        changes=changes,
        from_fingerprint=_fingerprint(previous, a),
        to_fingerprint=_fingerprint(current, b),
    )


@dataclass(frozen=True)
class RollbackEvidence:
    expected_current_revision: str
    target_revision_available: bool = False
    actor_authorized: bool = False
    recent_mfa_verified: bool = False
    product_rollback_supported: bool = False
    backup_verified: bool = False
    rollback_path_verified: bool = False
    out_of_band_recovery: bool = False
    audit_ready: bool = False

    def __post_init__(self) -> None:
        _ref(self.expected_current_revision, "expected current revision")
        for name in (
            "target_revision_available", "actor_authorized", "recent_mfa_verified",
            "product_rollback_supported", "backup_verified", "rollback_path_verified",
            "out_of_band_recovery", "audit_ready",
        ):
            if type(getattr(self, name)) is not bool:
                raise ValueError("invalid rollback evidence")


class RollbackBlocker(str, Enum):
    NONHISTORICAL_TARGET = "nonhistorical_target"
    WRONG_REVISION = "wrong_revision"
    NO_TARGET = "no_target"
    SAME_REVISION = "same_revision"
    UNSUPPORTED = "unsupported"
    UNAUTHORIZED = "unauthorized"
    MFA_REQUIRED = "mfa_required"
    BACKUP_MISSING = "backup_missing"
    RECOVERY_UNAVAILABLE = "recovery_unavailable"
    OUT_OF_BAND_REQUIRED = "out_of_band_required"
    AUDIT_UNAVAILABLE = "audit_unavailable"
    NONREVERSIBLE_FIELD = "nonreversible_field"


@dataclass(frozen=True)
class RollbackPreview:
    product_ref: str
    from_revision: str
    target_revision: str
    changed_paths: tuple[str, ...]
    blockers: tuple[RollbackBlocker, ...]
    may_submit_to_product_authority: bool
    product_apply_required: bool = True


def preview_config_rollback(
    current: ConfigRevision,
    target: ConfigRevision,
    *,
    allowlisted_paths: frozenset[str],
    reversible_paths: frozenset[str],
    evidence: RollbackEvidence,
) -> RollbackPreview:
    """Advisory only: caller must atomically revalidate and apply in product."""
    allowed = _registry(allowlisted_paths, "configuration allowlist")
    reversible = _registry(reversible_paths, "reversible field allowlist")
    if not reversible.issubset(allowed):
        raise ValueError("reversible paths must be within allowlist")
    # The product must prove target revision belongs to a real known history.
    d = diff_configurations(current, target, allowlisted_paths=allowed)
    blockers: list[RollbackBlocker] = []
    if evidence.expected_current_revision != current.revision_ref:
        blockers.append(RollbackBlocker.WRONG_REVISION)
    if not evidence.target_revision_available:
        blockers.append(RollbackBlocker.NO_TARGET)
    if current.revision_ref == target.revision_ref:
        blockers.append(RollbackBlocker.SAME_REVISION)
    if target.created_at > current.created_at:
        blockers.append(RollbackBlocker.NONHISTORICAL_TARGET)
    if not evidence.product_rollback_supported:
        blockers.append(RollbackBlocker.UNSUPPORTED)
    if not evidence.actor_authorized:
        blockers.append(RollbackBlocker.UNAUTHORIZED)
    if not evidence.recent_mfa_verified:
        blockers.append(RollbackBlocker.MFA_REQUIRED)
    if not evidence.backup_verified:
        blockers.append(RollbackBlocker.BACKUP_MISSING)
    if not evidence.rollback_path_verified:
        blockers.append(RollbackBlocker.RECOVERY_UNAVAILABLE)
    if not evidence.out_of_band_recovery:
        blockers.append(RollbackBlocker.OUT_OF_BAND_REQUIRED)
    if not evidence.audit_ready:
        blockers.append(RollbackBlocker.AUDIT_UNAVAILABLE)
    if any(c.path not in reversible for c in d.changes):
        blockers.append(RollbackBlocker.NONREVERSIBLE_FIELD)
    return RollbackPreview(
        product_ref=current.product_ref, from_revision=current.revision_ref,
        target_revision=target.revision_ref,
        changed_paths=tuple(c.path for c in d.changes),
        blockers=tuple(blockers),
        may_submit_to_product_authority=not blockers,
    )
