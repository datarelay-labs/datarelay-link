"""Pure, metadata-only lifecycle contract for product-owned credentials and keys.

This module NEVER receives secret material, rotates a key, changes access
permissions, encrypts/decrypts, contacts KMS or reads a credential store.
Products must provide authoritative revision, actor, backup and binding facts.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import re

_REFERENCE = re.compile(r"[a-z][a-z0-9_.-]{0,95}", re.ASCII)


def _reference(value: str, field_name: str) -> str:
    if not isinstance(value, str) or _REFERENCE.fullmatch(value) is None:
        raise ValueError("invalid " + field_name)
    return value


def _utc_seconds(value: int | None, name: str) -> None:
    if value is not None and (type(value) is not int or not 0 <= value <= 2**63 - 1):
        raise ValueError("invalid " + name)


class SecretKind(str, Enum):
    APPLICATION_CREDENTIAL = "application_credential"
    ENCRYPTION_KEY = "encryption_key"
    TLS_PRIVATE_KEY = "tls_private_key"
    TRANSPORT_CREDENTIAL = "transport_credential"


class SecretState(str, Enum):
    ACTIVE = "active"
    DISABLED = "disabled"
    COMPROMISED = "compromised"
    REVOKED = "revoked"


@dataclass(frozen=True)
class SecretMetadata:
    """Source-independent metadata, explicitly excluding any credential value.

    Reference and version are opaque product identifiers, not user-supplied
    display labels. Do not place a plaintext secret in any identifier.
    """
    reference: str
    kind: SecretKind
    state: SecretState
    revision: str
    created_at: int
    rotated_at: int | None = None
    expires_at: int | None = None
    dependency_count: int = 0

    def __post_init__(self) -> None:
        _reference(self.reference, "secret reference")
        _reference(self.revision, "secret revision")
        if type(self.kind) is not SecretKind:
            raise ValueError("invalid secret kind")
        if type(self.state) is not SecretState:
            raise ValueError("invalid secret state")
        _utc_seconds(self.created_at, "creation time")
        _utc_seconds(self.rotated_at, "rotation time")
        _utc_seconds(self.expires_at, "expiry time")
        if self.rotated_at is not None and self.rotated_at < self.created_at:
            raise ValueError("rotation time precedes creation")
        if self.expires_at is not None and self.expires_at <= self.created_at:
            raise ValueError("expiry must follow creation")
        if type(self.dependency_count) is not int or not 0 <= self.dependency_count <= 10**6:
            raise ValueError("invalid dependency count")


@dataclass(frozen=True)
class SecretLifecyclePolicy:
    """Organizational defaults, not an override of stronger product rules."""
    rotation_interval_seconds: int = 90 * 86400
    warn_before_expiry_seconds: int = 14 * 86400
    allow_manual_rotation: bool = True
    require_verified_recovery: bool = True

    def __post_init__(self) -> None:
        if type(self.rotation_interval_seconds) is not int:
            raise ValueError("invalid rotation interval")
        if type(self.warn_before_expiry_seconds) is not int:
            raise ValueError("invalid warning window")
        _utc_seconds(self.rotation_interval_seconds, "rotation interval")
        _utc_seconds(self.warn_before_expiry_seconds, "expiry warning interval")
        if not 86400 <= self.rotation_interval_seconds <= 3650 * 86400:
            raise ValueError("invalid rotation interval")
        if not 0 <= self.warn_before_expiry_seconds <= self.rotation_interval_seconds:
            raise ValueError("invalid warning window")
        if type(self.allow_manual_rotation) is not bool or type(self.require_verified_recovery) is not bool:
            raise ValueError("invalid lifecycle policy switch")


class SecretHealth(str, Enum):
    INVALID_EVIDENCE = "invalid_evidence"
    HEALTHY = "healthy"
    ROTATION_DUE = "rotation_due"
    EXPIRING = "expiring"
    EXPIRED = "expired"
    DISABLED = "disabled"
    COMPROMISED = "compromised"
    REVOKED = "revoked"


@dataclass(frozen=True)
class SecretPublicSummary:
    """Always safe to serialize as a status projection; no material or URI."""
    reference: str
    kind: SecretKind
    revision: str
    health: SecretHealth
    expires_at: int | None
    rotated_at: int | None
    dependency_count: int
    masked_value: str = field(default="********", init=False)


def describe_secret(
    metadata: SecretMetadata,
    *,
    now: int,
    policy: SecretLifecyclePolicy = SecretLifecyclePolicy(),
) -> SecretPublicSummary:
    _utc_seconds(now, "evaluation time")
    if metadata.state is SecretState.DISABLED:
        state = SecretHealth.DISABLED
    elif metadata.state is SecretState.COMPROMISED:
        state = SecretHealth.COMPROMISED
    elif metadata.state is SecretState.REVOKED:
        state = SecretHealth.REVOKED
    elif metadata.created_at > now or (
        metadata.rotated_at is not None and metadata.rotated_at > now
    ):
        # Do not mistake future-dated/clock-skewed metadata for a current
        # valid active key; the product must reconcile trusted time evidence.
        state = SecretHealth.INVALID_EVIDENCE
    elif metadata.expires_at is not None and now >= metadata.expires_at:
        state = SecretHealth.EXPIRED
    elif metadata.expires_at is not None and metadata.expires_at - now <= policy.warn_before_expiry_seconds:
        state = SecretHealth.EXPIRING
    elif now - (metadata.rotated_at if metadata.rotated_at is not None else metadata.created_at) >= policy.rotation_interval_seconds:
        state = SecretHealth.ROTATION_DUE
    else:
        state = SecretHealth.HEALTHY

    return SecretPublicSummary(
        reference=metadata.reference, kind=metadata.kind, revision=metadata.revision,
        health=state, expires_at=metadata.expires_at,
        rotated_at=metadata.rotated_at, dependency_count=metadata.dependency_count,
    )


@dataclass(frozen=True)
class RotationEvidence:
    """Product-supplied facts; never a command, credential or approval token."""
    expected_revision: str
    actor_authorized: bool = False
    recent_mfa_verified: bool = False
    secret_backend_supported: bool = False
    recovery_copy_verified: bool = False
    rollback_ready: bool = False
    dependent_bindings_ready: bool = False
    active_consumers_drained: bool = False
    audit_persistence_ready: bool = False

    def __post_init__(self) -> None:
        _reference(self.expected_revision, "expected revision")
        for key in (
            "actor_authorized", "recent_mfa_verified", "secret_backend_supported",
            "recovery_copy_verified", "rollback_ready",
            "dependent_bindings_ready", "active_consumers_drained",
            "audit_persistence_ready",
        ):
            if type(getattr(self, key)) is not bool:
                raise ValueError("invalid rotation evidence flag")


class RotationBlocker(str, Enum):
    UNSUPPORTED_BACKEND = "unsupported_backend"
    UNAUTHORIZED = "unauthorized"
    MFA_REQUIRED = "mfa_required"
    STALE_REVISION = "stale_revision"
    NOT_ACTIVE = "not_active"
    ROTATION_DISABLED = "rotation_disabled"
    RECOVERY_NOT_VERIFIED = "recovery_not_verified"
    ROLLBACK_NOT_READY = "rollback_not_ready"
    BINDINGS_UNPREPARED = "bindings_unprepared"
    ACTIVE_CONSUMERS = "active_consumers"
    AUDIT_UNAVAILABLE = "audit_unavailable"


@dataclass(frozen=True)
class RotationPreview:
    reference: str
    revision: str
    can_proceed_to_product_authority: bool
    blockers: tuple[RotationBlocker, ...]
    requires_product_apply: bool = True


def preview_secret_rotation(
    metadata: SecretMetadata,
    evidence: RotationEvidence,
    *,
    policy: SecretLifecyclePolicy = SecretLifecyclePolicy(),
) -> RotationPreview:
    """Read-only advisory preview. NEVER authorizes execution of key rotation.

    Product adapters must revalidate facts under a product-owned transaction
    and use a rollback/dual-key strategy appropriate for their secret store.
    """
    blockers: list[RotationBlocker] = []
    if not evidence.secret_backend_supported:
        blockers.append(RotationBlocker.UNSUPPORTED_BACKEND)
    if not evidence.actor_authorized:
        blockers.append(RotationBlocker.UNAUTHORIZED)
    if not evidence.recent_mfa_verified:
        blockers.append(RotationBlocker.MFA_REQUIRED)
    if evidence.expected_revision != metadata.revision:
        blockers.append(RotationBlocker.STALE_REVISION)
    if metadata.state is not SecretState.ACTIVE:
        blockers.append(RotationBlocker.NOT_ACTIVE)
    if not policy.allow_manual_rotation:
        blockers.append(RotationBlocker.ROTATION_DISABLED)
    if policy.require_verified_recovery and not evidence.recovery_copy_verified:
        blockers.append(RotationBlocker.RECOVERY_NOT_VERIFIED)
    if not evidence.rollback_ready:
        blockers.append(RotationBlocker.ROLLBACK_NOT_READY)
    if metadata.dependency_count and not evidence.dependent_bindings_ready:
        blockers.append(RotationBlocker.BINDINGS_UNPREPARED)
    if not evidence.active_consumers_drained:
        blockers.append(RotationBlocker.ACTIVE_CONSUMERS)
    if not evidence.audit_persistence_ready:
        blockers.append(RotationBlocker.AUDIT_UNAVAILABLE)

    return RotationPreview(
        reference=metadata.reference, revision=metadata.revision,
        can_proceed_to_product_authority=not blockers,
        blockers=tuple(blockers),
    )
