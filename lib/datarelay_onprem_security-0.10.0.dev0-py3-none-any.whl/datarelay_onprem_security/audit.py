"""Strict, transport-neutral administrative audit forwarding primitives.

This module has no network, filesystem, credentials, account or session authority.
A product owns audit event creation/permission checks, a durable retry queue,
its configured TLS/file destination, and successful delivery read-back.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import ipaddress
import json
import re
from types import MappingProxyType
from typing import Mapping, Protocol

_TOKEN_RE = re.compile(r"[A-Za-z0-9_.:@-]{1,128}", re.ASCII)
_ACTION_RE = re.compile(r"[a-z][a-z0-9_.-]{0,95}", re.ASCII)
_HOST_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9.-]{0,252}", re.ASCII)
# No message bodies, request payloads, credentials, URLs, HTTP headers or user
# free-form descriptions belong in an audit-forwarding event.
SAFE_DETAIL_KEYS = frozenset({
    "capability", "policy_revision", "reason_code", "resource_kind",
    "operation_ref", "surface", "scope",
})
MAX_DETAIL_ITEMS = 7
MAX_SYSLOG_BYTES = 4096


class AuditOutcome(str, Enum):
    SUCCESS = "success"
    DENIED = "denied"
    FAILED = "failed"


def _token(value: str, label: str) -> str:
    if not isinstance(value, str) or not _TOKEN_RE.fullmatch(value):
        raise ValueError("invalid " + label)
    return value


def _action(value: str) -> str:
    if not isinstance(value, str) or not _ACTION_RE.fullmatch(value):
        raise ValueError("invalid audit action")
    return value


@dataclass(frozen=True)
class AdminAuditEvent:
    """Only opaque identifiers and explicitly allowlisted safe detail fields.

    Every actor/action must already have been validated by the product's
    authoritative audit layer. Unknown extra fields reject the whole event.
    """
    event_id: str
    occurred_at: datetime
    actor_id: str
    action: str
    outcome: AuditOutcome
    resource_kind: str
    resource_id: str
    source_ip: str | None = None
    details: Mapping[str, str | int | bool] = field(default_factory=dict)

    def __post_init__(self) -> None:
        for name in ("event_id", "actor_id", "resource_kind", "resource_id"):
            _token(getattr(self, name), name)
        _action(self.action)
        if not isinstance(self.occurred_at, datetime) or self.occurred_at.tzinfo is None:
            raise ValueError("audit event requires timezone-aware timestamp")
        if self.occurred_at.utcoffset() is None:
            raise ValueError("audit event requires valid UTC offset")
        if not isinstance(self.outcome, AuditOutcome):
            raise ValueError("invalid audit outcome")
        if self.source_ip is not None:
            try:
                source = ipaddress.ip_address(self.source_ip)
            except (ValueError, TypeError) as exc:
                raise ValueError("invalid audit source IP") from exc
            if isinstance(source, ipaddress.IPv6Address) and source.ipv4_mapped:
                source = source.ipv4_mapped
            object.__setattr__(self, "source_ip", str(source))
        if not isinstance(self.details, Mapping) or len(self.details) > MAX_DETAIL_ITEMS:
            raise ValueError("invalid audit detail mapping")
        safe = {}
        for key, value in self.details.items():
            if key not in SAFE_DETAIL_KEYS:
                raise ValueError("audit detail field is not allowlisted")
            # Reject free text, multiline values, nested JSON and arbitrary
            # strings that could contain request bodies or credentials.
            if type(value) is str:
                safe[key] = _token(value, "audit detail")
            elif type(value) in (int, bool) and (
                type(value) is bool or (0 <= value <= (2 ** 53 - 1))
            ):
                safe[key] = value
            else:
                raise ValueError("invalid audit detail value")
        object.__setattr__(self, "details", MappingProxyType(safe))


def canonical_event(event: AdminAuditEvent) -> dict[str, object]:
    """Produce only validated fields; never serialize an arbitrary dataclass."""
    if not isinstance(event, AdminAuditEvent):
        raise ValueError("invalid audit event")
    stamp = event.occurred_at.astimezone(timezone.utc).isoformat(timespec="seconds")
    stamp = stamp.replace("+00:00", "Z")
    return {
        "action": event.action,
        "actor_id": event.actor_id,
        "details": dict(event.details),
        "event_id": event.event_id,
        "occurred_at": stamp,
        "outcome": event.outcome.value,
        "resource_id": event.resource_id,
        "resource_kind": event.resource_kind,
        "source_ip": event.source_ip,
    }


def encode_rfc5424(event: AdminAuditEvent, *, hostname: str, max_bytes: int = MAX_SYSLOG_BYTES) -> bytes:
    """Build deterministic RFC5424 local0 syslog frame (no network I/O).

    Strictly bounded single-line UTF-8 payload, with zero caller-controlled
    syslog header syntax. Failed/denied events use WARNING, successes NOTICE.
    """
    if not isinstance(hostname, str) or not _HOST_RE.fullmatch(hostname):
        raise ValueError("invalid syslog hostname")
    if type(max_bytes) is not int or not 512 <= max_bytes <= 65536:
        raise ValueError("invalid syslog frame limit")
    payload = canonical_event(event)
    msg = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    stamp = payload["occurred_at"]
    severity = 5 if event.outcome is AuditOutcome.SUCCESS else 4
    pri = 16 * 8 + severity  # LOCAL0 facility
    frame = f"<{pri}>1 {stamp} {hostname} datarelay - ADMIN_AUDIT - {msg}".encode("ascii")
    if len(frame) > max_bytes:
        raise ValueError("audit frame is too large")
    return frame


class AuditTransport(Protocol):
    """Injected **product-owned** audited destination; no default network send."""
    def send(self, frame: bytes) -> bool:
        """Return true only after durable acceptance or authenticated delivery."""


class DeliveryStatus(str, Enum):
    ACCEPTED = "accepted"
    RETRY_PENDING = "retry_pending"


@dataclass(frozen=True)
class ForwardReceipt:
    event_id: str
    status: DeliveryStatus


def forward_event(
    event: AdminAuditEvent,
    *,
    hostname: str,
    transport: AuditTransport,
    max_bytes: int = MAX_SYSLOG_BYTES,
) -> ForwardReceipt:
    """Perform one bounded attempt using an explicitly provided product sink.

    Encoding is performed before calling any transport. Transport exceptions
    and false acknowledgements become RETRY_PENDING; no credential-bearing
    exception messages escape to UI or audit logs. The product must enqueue
    and retry durably, and must not report delivered until real sink receipt.
    """
    frame = encode_rfc5424(event, hostname=hostname, max_bytes=max_bytes)
    try:
        accepted = transport.send(frame) is True
    except Exception:
        accepted = False
    return ForwardReceipt(
        event_id=event.event_id,
        status=DeliveryStatus.ACCEPTED if accepted else DeliveryStatus.RETRY_PENDING,
    )
