"""RFC 6238 TOTP primitives. Credential/session/storage authority remains with each product.

All functions are deliberately pure: they cannot issue login sessions, mutate
accounts, or access a database. A caller must commit the returned counter
atomically with any successful MFA challenge to prevent OTP reuse.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
from enum import Enum
import hashlib
import hmac
import re
import secrets
import struct
import time
from urllib.parse import quote, urlencode

_TOTP_DIGITS = 6
_TOTP_PERIOD = 30
_BASE32 = re.compile(r"[A-Z2-7]{16,}", re.ASCII)
_CODE = re.compile(r"[0-9]{6}", re.ASCII)


def new_totp_secret() -> str:
    """Cryptographically random 160-bit secret, shown once during enrollment."""
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")


def _decode_secret(secret: str) -> bytes:
    raw = secret.strip().replace(" ", "").upper() if isinstance(secret, str) else ""
    if not _BASE32.fullmatch(raw):
        raise ValueError("invalid TOTP secret")
    try:
        decoded = base64.b32decode(raw + "=" * (-len(raw) % 8), casefold=False)
    except (ValueError, base64.binascii.Error) as exc:
        raise ValueError("invalid TOTP secret") from exc
    if len(decoded) < 10:
        raise ValueError("invalid TOTP secret length")
    return decoded


def code_at(secret: str, timestamp: int | float, *, digits: int = _TOTP_DIGITS) -> str:
    """Deterministic RFC 6238 SHA-1 code; caller controls clock in tests."""
    if digits != 6:
        raise ValueError("only standard 6-digit TOTP is supported")
    key = _decode_secret(secret)
    counter = int(timestamp) // _TOTP_PERIOD
    if counter < 0:
        raise ValueError("negative TOTP counter")
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 15
    truncated = int.from_bytes(digest[offset : offset + 4], "big") & 0x7FFFFFFF
    return str(truncated % (10 ** digits)).zfill(digits)


def verify_totp(
    secret: str,
    code: str,
    *,
    now: int | float | None = None,
    last_counter: int | None = None,
    allowed_drift_steps: int = 1,
) -> int | None:
    """Return matched counter or None. Persist a counter strictly greater than last_counter.

    A caller MUST atomically check/update the stored counter and MUST NOT issue
    an authenticated session before that write succeeds.
    """
    if not isinstance(code, str) or not _CODE.fullmatch(code):
        return None
    if allowed_drift_steps < 0 or allowed_drift_steps > 1:
        raise ValueError("TOTP window may not exceed one adjacent step")
    current = int(time.time() if now is None else now) // _TOTP_PERIOD
    if current < 0:
        return None
    # Prefer earlier/current/later windows, with strict replay protection.
    for counter in range(current - allowed_drift_steps, current + allowed_drift_steps + 1):
        if counter < 0 or (last_counter is not None and counter <= last_counter):
            continue
        if hmac.compare_digest(code_at(secret, counter * _TOTP_PERIOD), code):
            return counter
    return None


def provisioning_uri(secret: str, *, issuer: str, account: str) -> str:
    """Offline QR payload; keep both the URI and the secret out of logs."""
    _decode_secret(secret)
    if not issuer.strip() or not account.strip():
        raise ValueError("issuer and account are required")
    label = quote(f"{issuer}:{account}", safe="")
    params = urlencode({"secret": secret, "issuer": issuer, "algorithm": "SHA1", "digits": 6, "period": 30})
    return f"otpauth://totp/{label}?{params}"


class PasswordResult(str, Enum):
    AUTHENTICATED = "authenticated"
    MFA_REQUIRED = "mfa_required"
    MFA_ENROLLMENT_REQUIRED = "mfa_enrollment_required"


@dataclass(frozen=True)
class UserMfaState:
    required: bool = False  # Default OFF for every new account.
    enrolled: bool = False

    def after_verified_password(self) -> PasswordResult:
        """Only AUTHENTICATED permits issuing a full session.

        The two other states require a limited pre-auth challenge; neither may
        possess a usable session/JWT. Product adapters enforce the boundary.
        """
        if not self.required:
            return PasswordResult.AUTHENTICATED
        return PasswordResult.MFA_REQUIRED if self.enrolled else PasswordResult.MFA_ENROLLMENT_REQUIRED


def new_recovery_codes(count: int = 8) -> tuple[str, ...]:
    if not 1 <= count <= 20:
        raise ValueError("invalid recovery count")
    return tuple(secrets.token_hex(12) for _ in range(count))


def recovery_code_digest(code: str, *, installation_key: bytes) -> str:
    """HMAC prevents an offline SHA256 dictionary of short recovery codes.

    The product must keep installation_key in its secret store, atomically
    consume the selected digest once, and never return raw codes again.
    """
    if not isinstance(installation_key, bytes) or len(installation_key) < 32:
        raise ValueError("installation HMAC key must be at least 32 bytes")
    normalized = code.strip().lower() if isinstance(code, str) else ""
    if not re.fullmatch(r"[0-9a-f]{24}", normalized, re.ASCII):
        raise ValueError("invalid recovery code")
    return hmac.new(installation_key, normalized.encode("ascii"), hashlib.sha256).hexdigest()
